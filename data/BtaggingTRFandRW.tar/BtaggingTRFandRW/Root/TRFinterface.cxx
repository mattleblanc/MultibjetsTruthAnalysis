#include "BtaggingTRFandRW/TRFinterface.h"
#include "BtaggingTRFandRW/BtagOP.h"

#include <iostream>
#include <sstream>
#include <fstream>
#include <cmath>
#include <vector>

#include <TStopwatch.h>
#include <TSystem.h>

using namespace std;

TRFinterface::TRFinterface(string confFile, double OP, string jetCol, bool ignoreSF, bool checkClosure, unsigned int debug)
{
  m_OP = OP;
  m_jetCol = jetCol;
  m_debug = debug;
  m_checkClosure = checkClosure;
  initializeCalibrations(confFile);
  m_rwSystForPerm = true;
  m_rwSystForTagBins = true;
  m_testMode = ignoreSF;
  //m_testMode = true; // false: uses SF in calculating TRF weight
  m_useExtrapApproxErr = false;
}

TRFinterface::~TRFinterface()
{
}

map<int, string> TRFinterface::setPdgFlav()
{
  map<int, string> tmpMap;
  tmpMap[5] = "B";
  tmpMap[4] = "C";
  tmpMap[15] = "T";
  tmpMap[0] = "Light";
  return tmpMap;
}

map<int, string> TRFinterface::m_pdgFlav = setPdgFlav();

void TRFinterface::initializeCalibrations(string confFile)
{
  string line="";
  ifstream confile(confFile.c_str());
  if(confile.is_open()) {
    while(std::getline( confile, line )) {
      if(line.at(0) == '#') continue;
      std::stringstream iss(line);
      BtagCalib tmpBC;
      tmpBC.nmaps = 1; // has to be initialized here as not possible in .h for old C++...
      iss >> tmpBC.name >> tmpBC.confFile >> tmpBC.tagAlgo >> tmpBC.jetColSF >> tmpBC.jetColEff >> tmpBC.exceptSF >> std::boolalpha >> tmpBC.useSF >> tmpBC.nmaps;
      tmpBC.inverseJetCol = (tmpBC.jetColSF != m_jetCol) ? true : false ;
      tmpBC.inverseJetColEff = (tmpBC.jetColEff != m_jetCol) ? true : false ;
      tmpBC.isCont = (tmpBC.name.find("Cont") != string::npos) ? true : false;
      tmpBC.isContTRF = (tmpBC.isCont && (tmpBC.name.find("TRF") != string::npos || tmpBC.name.find("Trf") != string::npos)) ? true : false;
      string jetcalalg = "LC";
      if(m_jetCol.find("LC") == string::npos) jetcalalg = "EM";
      if(tmpBC.isCont) jetcalalg += "cont";
      else jetcalalg += "cum";
      jetcalalg += tmpBC.tagAlgo;
      tmpBC.jetCalAlg = jetcalalg;
      string jetcalalgInv = (jetcalalg.find("LC") != string::npos) ? 
  	jetcalalg.replace(jetcalalg.begin(),jetcalalg.begin()+2,"EM") : jetcalalg.replace(jetcalalg.begin(),jetcalalg.begin()+2,"LC");
      tmpBC.jetCalAlgInv = jetcalalgInv;
      tmpBC.OPbin = BtagOP::getLCbin(m_OP,tmpBC.jetCalAlg);
      m_calibMap[tmpBC.name] = tmpBC;
      // If only one calib -> TRF only case (no reweighting) -> save the calib name in m_calibName, to simplify user calls to functions
      if(m_calibMap.size() == 1) {
	m_calibName = m_calibMap.begin()->first;
	cout << "[31m" << m_calibName << " set as reference if RW is needed. If this is not the calibration you want to use as reference please call setReferenceCalib later or cahnge the order of calibration in your configuration file.[0m" << endl;
      }
    }
  }

  map<string,int> jetflav;
  jetflav["B"] = 5;
  jetflav["C"] = 4;
  jetflav["T"] = 15;
  jetflav["Light"] = 0;
  
  map<std::string, BtagCalib>::iterator calit = m_calibMap.begin();
  for( ; calit != m_calibMap.end(); calit++) {
    string calname = calit->first;
    cout << "calname = " << calname << endl;
    string pathToConf = gSystem->Getenv("ROOTCOREBIN");
    if(pathToConf == "") cout << "Issue in the ROOTCORBIN path" << endl;
    m_cdiTools[calname] = new Analysis::CalibrationDataInterfaceROOT(calit->second.tagAlgo,pathToConf+"/"+calit->second.confFile,"");
    vector<string> opstrSF, opstrEff;
    string flagSF = getCalibOPflag(calname,calit->second.jetColSF,calit->second.tagAlgo);
    string flagEff = getCalibOPflag(calname,calit->second.jetColEff,calit->second.tagAlgo);
    if(!calit->second.isCont) {
      opstrSF.assign(BtagOP::op_TagW_str[flagSF].begin()+1,BtagOP::op_TagW_str[flagSF].end()-1);
      opstrEff.assign(BtagOP::op_TagW_str[flagEff].begin()+1,BtagOP::op_TagW_str[flagEff].end()-1);
    } 
    else {
      opstrSF.assign(BtagOP::op_TagW_str[flagSF].begin(),BtagOP::op_TagW_str[flagSF].end());
      opstrEff.assign(BtagOP::op_TagW_str[flagEff].begin(),BtagOP::op_TagW_str[flagEff].end());
    }
    if(m_debug > 2) {
      cout << "flagSF = " << flagSF << "  flagEff = " << flagEff << endl;
      cout << "Eff OPs:" << endl;
      for(unsigned int ie=0; ie<opstrEff.size(); ie++) cout << "op " << ie << " = " << opstrEff.at(ie) << endl;
      cout << "SF OPs:" << endl;
      for(unsigned int is=0; is<opstrSF.size(); is++) cout << "op " << is << " = " << opstrSF.at(is) << endl;
    }

    map<string,int>::iterator ft = jetflav.begin();
    for(; ft != jetflav.end(); ft++) {

      if(calit->second.nmaps != 1) {
	cout << "NbEffMaps = " << calit->second.nmaps << endl;
	cout << "[31mYou will use efficiency maps that are dependent on origin of the jet (top/W vs other), your *.env file has to contain at least " << calit->second.nmaps << " maps." << endl;
	cout << "Please set " << calit->second.nmaps << " times the same map for flavours where you would not have same treatment, else initialization will fail (crash).[0m" << endl;
      }

      string uflagSF = flagSF, jetColSF = calit->second.jetColSF;
      vector<string> uopstrSF(opstrSF);
      if(calit->second.exceptSF.find(ft->first) != string::npos) {
  	uflagSF = flagEff;
  	uopstrSF = opstrEff;
  	jetColSF = calit->second.jetColEff;
      }
      if(uopstrSF.size() != opstrEff.size()) {cout << "Issue in number of OP for SF and efficiencies, please check" << endl; exit(-1);}

      for(unsigned int iop = 0; iop<uopstrSF.size(); iop++) {
	// get SF indexes
  	bool gotIndex = m_cdiTools[calname]->retrieveCalibrationIndex(ft->first,uopstrSF.at(iop),jetColSF,true,calit->second.iSF[ft->second][iop]);
  	if(!gotIndex) cout << "ERROR: could not get index of " << ft->first << " SF" << endl;
  	if(m_debug > 2) cout << "[31mSFindex = " << calit->second.iSF[ft->second][iop] << "  pour " << ft->first << "(" << ft->second << ") et OP = " << uopstrSF.at(iop) 
  			     << "(" << BtagOP::matchMap_opStr[uopstrSF.at(iop)] << ")" << "  jetColSF = " << jetColSF << "[0m" << endl;

	// get efficiencies indexes
	vector<unsigned int> vtmp(calit->second.nmaps,0);
	calit->second.iEff[ft->second][iop] = vtmp;
	for(unsigned int ie=0; ie<vtmp.size(); ie++) {
	  gotIndex = m_cdiTools[calname]->retrieveCalibrationIndex(ft->first,opstrEff.at(iop),calit->second.jetColEff,false,
								   calit->second.iEff[ft->second][iop][ie],ie);
	  if(!gotIndex) cout << "ERROR: could not get index of " << ft->first << " Eff" << endl;
	  if(m_debug > 2) cout << "index = " << calit->second.iEff[ft->second][BtagOP::matchMap_opStr[opstrEff.at(iop)]].at(ie) << "  pour " << ft->first 
			       << "(" << ft->second << ") et OP = " << opstrEff.at(iop)
			       << "(" << BtagOP::matchMap_opStr[opstrEff.at(iop)] << ")" << "  jetColEff = " << calit->second.jetColEff << endl;
	}
      }
      // number of EV is the same for all OP -> always look at first OP, ie iop=0
      calit->second.nEV[ft->second] = m_cdiTools[calname]->getNumVariations(calit->second.iSF[ft->second][0],Analysis::SFEigen);
      if(m_debug > 4) cout << "nbre EV: " << ft->first << " = "  << calit->second.nEV[ft->second] << endl;
      // get the index of the extrapolation uncertainty
      vector<string> listSyst = m_cdiTools[calname]->listScaleFactorUncertainties(calit->second.iSF[ft->second][0],true);
      for(unsigned int ils=0; ils<listSyst.size(); ils++) {
	if(m_debug > 4) cout << "syst = " << listSyst.at(ils) << endl;
	if(listSyst.at(ils) == "extrapolation")  calit->second.extrapUnc[ft->second] = ils;
      }
    }
  }
}

unsigned int TRFinterface::getNumEV(unsigned int pdgid_EV, string calib)
{
  return m_calibMap[calib].nEV[pdgid_EV];
}

string TRFinterface::getCalibOPflag(string calname, string jetcol, string tagalgo)
{
  string opid = "LC";
  if(jetcol.find("EM") != string::npos) opid = "EM";
  if(calname.find("Cum") != string::npos) opid += "cum";
  else opid += "cont";
  opid += tagalgo;
  return opid;
}

double TRFinterface::getSF(double pt, double eta, int pdgid, double tagw, std::string calib, unsigned int imap, int ev, bool extrap)
{
  // supposing m_jetCol = LC jets
  unsigned int iOP = BtagOP::getLCbin(tagw,m_calibMap[calib].jetCalAlg);
  if(!m_calibMap[calib].isCont) iOP = m_calibMap[calib].OPbin-1; // as 3 OP (so 4 bins) saved in the map -> code is done for TRF
  return getSF(pt, eta, pdgid, iOP, calib, imap, ev, extrap);
}

double TRFinterface::getSF(double pt, double eta, int pdgid, unsigned int iop, std::string calib, unsigned int imap, int ev, bool extrap)
{
  if(m_debug > 5) cout << "getSF: pt = " << pt << "  eta = " << eta << "  pdgid = " << pdgid << "  iop = " << iop << "  calib = " << calib << "  map = " << imap << endl;
  if(m_testMode) return 1.;
  
  int pdg = (abs(pdgid) < 4) ? 0 : pdgid;
  double OP = (m_calibMap[calib].isCont) ? 0 : iop;

  Analysis::CalibrationDataVariables ajet;
  ajet.jetAuthor = m_calibMap[calib].jetColSF;
  ajet.jetPt = pt; // in MeV
  ajet.jetEta = eta;
  ajet.jetTagWeight = 1.; // not used in cumulative case -> can be any value (to simplify set to the requested OP value)
  if(m_calibMap[calib].isCont) {
    if(m_calibMap[calib].inverseJetCol && m_calibMap[calib].exceptSF.find(m_pdgFlav[abs(pdg)]) == string::npos) {
      ajet.jetTagWeight = BtagOP::mid_TagW[m_calibMap[calib].jetCalAlgInv].at(iop);
    } 
    else {
      ajet.jetTagWeight = BtagOP::mid_TagW[m_calibMap[calib].jetCalAlg].at(iop);
    }
  }

  if(m_debug > 5) cout << "OP = " << OP << "  iop = " << iop << "  jtw = " << ajet.jetTagWeight << endl;

  if(m_calibMap[calib].isCont) {
    if(extrap) {
      if(ev > 0) {
	double SF = m_cdiTools[calib]->getWeightScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][imap],
							    Analysis::SFNamed, m_calibMap[calib].extrapUnc[abs(pdg)]).first;
	return SF;
      } 
      else {
	double SF = m_cdiTools[calib]->getWeightScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][imap],
							    Analysis::SFNamed, m_calibMap[calib].extrapUnc[abs(pdg)]).second;
	return SF;
      } 
    } 
    else {
      if(ev == 0) {
	double SF = m_cdiTools[calib]->getWeightScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][imap], Analysis::Total).first;
	if(SF < 0) cout << "NEGATIVE SF!!! pdg = " << pdgid << "  pt = " << pt << "  eta = " << eta << "  tagw = " << ajet.jetTagWeight << endl;
	return SF;
      } 
      else if(ev > 0) {
	double SF = m_cdiTools[calib]->getWeightScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][imap],
							    Analysis::SFEigen,abs(ev)-1).first;
	if(SF < 0) cout << "NEGATIVE SF!!! pdg = " << pdgid << "  pt = " << pt << "  eta = " << eta << "  tagw = " << ajet.jetTagWeight << endl;
	return SF;
      } 
      else if(ev < 0) {
	double SF = m_cdiTools[calib]->getWeightScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][imap],
							    Analysis::SFEigen,abs(ev)-1).second;
	if(SF < 0) cout << "NEGATIVE SF!!! pdg = " << pdgid << "  pt = " << pt << "  eta = " << eta << "  tagw = " << ajet.jetTagWeight << endl;
	return SF;
      }
    }
  } 
  else {
    if(extrap) {
      if(ev > 0) {
	double SF = 1.;
	if(m_useExtrapApproxErr) SF = m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::Total).first * getExtrapApproxErr(pt, eta, pdgid);
	else SF = m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0], Analysis::SFNamed, m_calibMap[calib].extrapUnc[abs(pdg)]).first;
	return SF;
      } 
      else {
	double SF = 1.;
	if(m_useExtrapApproxErr) SF = m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::Total).first / getExtrapApproxErr(pt, eta, pdgid);
	else SF = m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0], Analysis::SFNamed, m_calibMap[calib].extrapUnc[abs(pdg)]).second;
	return SF;
      }
    } 
    else {
      if(ev == 0) return m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::Total).first;
      else if(ev > 0) return m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::SFEigen,abs(ev)-1).first;
      else if(ev < 0) return m_cdiTools[calib]->getScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::SFEigen,abs(ev)-1).second;
    }
  }
  return 1.;  
}

double TRFinterface::getExtrapApproxErr(double pt, double eta, int pdgid)
{
  if(abs(pdgid) == 5) {
    if(pt < 300000) return 1.;
    return 0.46395 + 2.40589e-6*pt - 2.25016e-12*pt*pt + 7.12931e-19*pt*pt*pt;
  } 
  else if(abs(pdgid) == 4 || abs(pdgid) == 15) {
    if(pt < 300000) return 1.;
    return 0.586669 + 1.83484e-6*pt - 1.50576e-12*pt*pt + 4.89775e-19*pt*pt*pt;
  } 
  else if(abs(pdgid) == 0) {
    if(pt < 750000) return 1.;
    if(fabs(eta) < 1.2) return -1.08232 + 4.43084e-6*pt - 2.56567e-12*pt*pt + 4.9032e-19*pt*pt*pt;
    else return 0.49 + 4.25e-7*pt;
  } 
  else return 1.;
}

double TRFinterface::getEff(double pt, double eta, int pdgid, double tagw, string calib, unsigned int imap)
{
  // supposing m_jetCol = LC jets
  unsigned int iOP = BtagOP::getLCbin(tagw,m_calibMap[calib].jetCalAlg);
  if(!m_calibMap[calib].isCont) iOP--; // as 3 OP (so 4 bins) saved in the map -> code is done for TRF
  return getEff(pt, eta, pdgid, iOP, calib, imap);
}

double TRFinterface::getEff(double pt, double eta, int pdgid, unsigned int iop, string calib, unsigned int imap)
{
  Analysis::CalibrationDataVariables ajet;
  ajet.jetAuthor = m_calibMap[calib].jetColEff;
  ajet.jetPt = pt; // in MeV
  ajet.jetEta = eta;
  ajet.jetTagWeight = 1.; // not used in cumultative case -> can be any value (to simplify set to the requested OP value)
  if(m_calibMap[calib].isCont) {
    if(!m_calibMap[calib].inverseJetColEff) {
      ajet.jetTagWeight = BtagOP::mid_TagW[m_calibMap[calib].jetCalAlg].at(iop);
    } 
    else {
      ajet.jetTagWeight = BtagOP::mid_TagW[m_calibMap[calib].jetCalAlgInv].at(iop);
    }
  }

  int pdg = (abs(pdgid) < 4) ? 0 : pdgid; 
  double OP = (m_calibMap[calib].isCont) ? 0 : iop;

  if(m_debug > 7) {
    cout << "[35mINFO: the possible efficiencies for calib " << calib << "  with " << m_calibMap[calib].nmaps << " maps (pdg = " << pdg << ") : " << endl;
    for(unsigned int ie=0; ie<m_calibMap[calib].nmaps; ie++) cout  << "ie: " << ie << " -> " << m_cdiTools[calib]->getMCEfficiency(ajet,m_calibMap[calib].iEff[abs(pdg)][OP][ie]).first << "   ; ";
    cout << "[0m" << endl;
    cout << "look for map " << imap << endl;
  }
  double eff = m_cdiTools[calib]->getMCEfficiency(ajet,m_calibMap[calib].iEff[abs(pdg)][OP][imap]).first;
  if(eff == 0) {
    cout << "[31mPlease check your maps for calib " << calib << ": bin at 0 = empty bin for pdg = " << pdgid << " and imap = " << imap << "[0m" << endl;
    eff = 1e-5;
  }
  //  std::cout << "pt " << pt << "   eta " << eta << "    pdgid " << pdgid << "   eff " << eff << "   iop " << iop << "   calib " << calib << "   imap " << imap << std::endl; // chiara
  return  eff;
}

double TRFinterface::getIneffSF(double pt, double eta, int pdgid, unsigned int iop, std::string calib, unsigned int imap, int ev, bool extrap)
{
  if(m_calibMap[calib].isCont) {cout << "[31mWhy are you here ? Inefficiencies are only used in cumulative case.[0m" << endl; return 1;}
  if(m_debug > 5) cout << "getSF: pt = " << pt << "  eta = " << eta << "  pdgid = " << pdgid << "  iop = " << iop << endl;
  if(m_testMode) return 1.;

  int pdg = (abs(pdgid) < 4) ? 0 : pdgid;
  double OP = (m_calibMap[calib].isCont) ? 0 : iop;

  Analysis::CalibrationDataVariables ajet;
  ajet.jetAuthor = m_calibMap[calib].jetColSF;
  ajet.jetPt = pt; // in MeV
  ajet.jetEta = eta;
  ajet.jetTagWeight = 1.; // not used in cumulative case -> can be any value (to simplify set to the requested OP value)
  
  // case when only one map is used
  if(imap == 0) {
    if(extrap) {
      if(ev > 0) return m_cdiTools[calib]->getInefficiencyScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],
								      Analysis::SFNamed, m_calibMap[calib].extrapUnc[abs(pdg)]).first;
      else return m_cdiTools[calib]->getInefficiencyScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],
								Analysis::SFNamed, m_calibMap[calib].extrapUnc[abs(pdg)]).second;
    } else {
      if(ev == 0) return m_cdiTools[calib]->getInefficiencyScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::Total).first;
      else if(ev > 0) return m_cdiTools[calib]->getInefficiencyScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::SFEigen,abs(ev)-1).first;
      else if(ev < 0) return m_cdiTools[calib]->getInefficiencyScaleFactor(ajet,m_calibMap[calib].iSF[abs(pdg)][OP], m_calibMap[calib].iEff[abs(pdg)][OP][0],Analysis::SFEigen,abs(ev)-1).second;
      else return 1;
    }
  }
  // else need to recalculate inefficiency by hand... 
  else {
    double SF = getSF(pt, eta, pdgid, iop, calib, 0, ev, extrap); // not extrapolation uncertainty per default; imap = 0 for cumulative
    double eff = getEff(pt, eta, pdgid, iop, calib, imap);
    double ineff = 1.;
    if(1. - eff > 1.e-6) {
      ineff = (1. - eff*SF) / (1. - eff);
    }
    if(ineff < 0.) ineff = 0.; // to prevent negative inefficiencies (but should NEVER happen if maps well checked)
    return ineff;
  }
}

int TRFinterface::getSystId(unsigned int pdgid_EV, int eigenv, bool extrap)
{
  if(extrap) {
    int id = eigenv > 0 ? 1000 + pdgid_EV * 100 + abs(eigenv) : - (1000 + pdgid_EV * 100 + abs(eigenv)) ;
    return id;
  }
  if(pdgid_EV == 999 || eigenv == 0) return 0; // nominal case
  int id = eigenv > 0 ? pdgid_EV * 100 + abs(eigenv) : - (pdgid_EV * 100 + abs(eigenv)) ;
  return id;
}

void TRFinterface::setJets(vector<double> pt, vector<double> eta, vector<int> pdg, vector<double> tagw)
{
  // cleaning for new event
  m_pt.clear(), m_eta.clear(), m_pdg.clear(), m_tagw.clear(), m_imap.clear();
  m_eff.clear(), m_SF.clear();
  m_trfRes.clear();

  m_pt = pt;
  m_eta = eta;
  m_pdg = pdg;
  m_tagw = tagw;
  m_imap.assign(m_pt.size(),0);

  // check eta
  for(unsigned int j=0; j<m_eta.size(); j++) {
    if(fabs(m_eta.at(j)) > 2.5) {
      cout << "Caution: jets with |eta| > 2.5 are not already taken into account -> exit" << endl;
      exit(-1);
    } 
  }
}

void TRFinterface::setJets(std::vector<double> pt, std::vector<double> eta, std::vector<int> pdg, std::vector<double> tagw, std::vector<unsigned int> imap)
{
  setJets(pt, eta, pdg, tagw);
  m_imap.clear();
  m_imap = imap;
}

void TRFinterface::setSeed(unsigned int seed)
{
  m_rand.SetSeed(seed);
}

void TRFinterface::getTRFweights(string calib, unsigned int limit, vector<double> &trf_weight_ex, vector<double> &trf_weight_in,
				 unsigned int pdgid_EV, int eigenv, bool extrap)
{
  int syst = getSystId(pdgid_EV,eigenv, extrap);
  getTRFweight(calib, limit, true, pdgid_EV, eigenv, extrap);
  if(syst == 0) { // nominal case
    m_trfRes[calib].trfw_ex = m_trfRes[calib].trfwsys_ex[0];
    m_trfRes[calib].trfw_in = m_trfRes[calib].trfwsys_in[0];
    trf_weight_ex = m_trfRes[calib].trfw_ex;
    trf_weight_in = m_trfRes[calib].trfw_in;
  } else {
    if(m_rwSystForPerm) {
      if(m_debug > 5) cout << "For syst, eigenv = " << eigenv << "  TRF: ex = " << m_trfRes[calib].trfwsys_ex[syst].at(3) << "  in = " << m_trfRes[calib].trfwsys_in[syst].at(3) << endl;
      for(unsigned int ib = 0; ib < m_trfRes[calib].trfwsys_ex[syst].size(); ib++) {
	m_trfRes[calib].trfwsys_ex[syst].at(ib) *= getPermutationRW(calib, false, ib, calib, pdgid_EV, eigenv, extrap);
	m_trfRes[calib].trfwsys_in[syst].at(ib) *= getPermutationRW(calib, true, ib, calib, pdgid_EV, eigenv, extrap);
	if(m_debug > 5 && ib == 3) cout << "[33mPERM: trf_ex = " << m_trfRes[calib].trfwsys_ex[syst].at(ib) << "  in = " << m_trfRes[calib].trfwsys_in[syst].at(ib) << "[0m" << endl;
	if(m_rwSystForTagBins) {
	  m_trfRes[calib].trfwsys_ex[syst].at(ib) *= getTagBinsRW(calib, false, ib, calib, pdgid_EV, eigenv, extrap);
	  m_trfRes[calib].trfwsys_in[syst].at(ib) *= getTagBinsRW(calib, true, ib, calib, pdgid_EV, eigenv, extrap);
	  if(m_debug > 5 && ib == 3) cout << "[32mTAG BINS: trf_ex = " << m_trfRes[calib].trfwsys_ex[syst].at(ib) << "  in = " << m_trfRes[calib].trfwsys_in[syst].at(ib) << "[0m" << endl;
	}
      }
    }
    trf_weight_ex = m_trfRes[calib].trfwsys_ex[syst];
    trf_weight_in = m_trfRes[calib].trfwsys_in[syst];
  }
}

double TRFinterface::getTRFweight(string calib, unsigned int nbtag, bool isInclusive, unsigned int pdgid_EV, int eigenv, bool extrap)
{
  int syst = getSystId(pdgid_EV, eigenv, extrap);
  if(m_debug > 3) cout << "in getTRFweight for syst = " << syst << " for maximally " << nbtag << "b-tagged jets" << endl;

  // get efficiencies
  getAllEff(calib);
  // get nominal SF
  getAllSF(calib, pdgid_EV, eigenv, extrap);

  if(m_debug > 7) cout << "maps have been initialized" << endl;
  if(m_debug > 3) {
    cout << "Eff and SF maps:" << endl;
    for(unsigned int ij=0; ij < m_trfRes[calib].eff.size(); ij++) {
      cout << "jet " << ij << " (flavour = " << m_pdg.at(ij) << ") : " << endl;
      for(unsigned int io=0; io<m_trfRes[calib].eff[ij].size(); io++)
	cout << "  " << m_trfRes[calib].eff[ij][io] << "   " << m_trfRes[calib].SF[ij][io] << endl;
    }
  }

  unsigned int njets = m_pt.size();
  unsigned int limit = (njets > 7) ? 8 : njets+1;

  if (m_perms.find(njets)==m_perms.end()){
    m_perms[njets] = vector<vector<vector<bool> > >(limit);
    for(unsigned int i=0;i<limit;i++)	
      m_perms[njets].at(i) = generatePermutations(njets,i);
  }
  m_permsWeight.clear(), m_permsWeight.resize(limit);
  m_permsSumWeight.clear(), m_permsSumWeight.resize(limit);

  if(m_debug > 10) printPermutations();

  // compute TRF weight
  unsigned int max = nbtag+1;
  
  m_trfRes[calib].trfwsys_ex[syst].clear(), m_trfRes[calib].trfwsys_in[syst].clear();
  m_trfRes[calib].trfwsys_ex[syst].resize(max), m_trfRes[calib].trfwsys_in[syst].resize(max);

  if(syst == 0) { // nominal case
    m_trfRes[calib].perm_ex.clear(), m_trfRes[calib].perm_in.clear();
    m_trfRes[calib].perm_ex.resize(max),  m_trfRes[calib].perm_in.resize(max);
    m_trfRes[calib].permprob_ex.clear(), m_trfRes[calib].permprob_in.clear();
    m_trfRes[calib].permprob_ex.resize(max),  m_trfRes[calib].permprob_in.resize(max);
    m_trfRes[calib].rwpcals_ex.clear(), m_trfRes[calib].rwpcals_in.clear();
    m_trfRes[calib].rwpcals_ex.resize(max,1.), m_trfRes[calib].rwpcals_in.resize(max,1.);
    m_trfRes[calib].rwtbcals_ex.clear(), m_trfRes[calib].rwtbcals_in.clear();
    m_trfRes[calib].rwtbcals_ex.resize(max,1.), m_trfRes[calib].rwtbcals_in.resize(max,1.);
  }

  if(isInclusive) {
    for(unsigned int i=0; i<limit; i++) { // need +1 as 0 is included
      vector<double> weights;
      double sum = 0., w = 0.;
      for(unsigned int p=0; p<m_perms[njets].at(i).size(); p++) {
  	w = trfWeight(m_perms[njets].at(i).at(p),calib);
  	sum+=w;
  	m_permsWeight.at(i).push_back(w);
  	m_permsSumWeight.at(i).push_back(sum);
    	if(m_debug > 8) cout << "nbtag = " << i << "  w = " << w << "  sum = " << sum << endl;
      }
     
      if(i<limit && i<max) {
  	m_trfRes[calib].trfwsys_ex[syst].at(i) = sum;
  	if(i == 0) m_trfRes[calib].trfwsys_in[syst].at(0) = 1.;
  	else m_trfRes[calib].trfwsys_in[syst].at(i) = m_trfRes[calib].trfwsys_in[syst].at(i-1) - m_trfRes[calib].trfwsys_ex[syst].at(i-1);
	if(m_debug > 8) cout << "i = " << i << "  sum = " << sum << "  TRF in " << m_trfRes[calib].trfwsys_in[0].at(i) << "  ex = " << m_trfRes[calib].trfwsys_ex[0].at(i) << endl;
      }
    }
    if(m_debug > 7) cout << "avant le return, nbtag = " << nbtag << "  size de m_trfRes[calib].trfwsys_in[syst] = " << m_trfRes[calib].trfwsys_in[syst].size() << endl;
    return m_trfRes[calib].trfwsys_in[syst].at(nbtag);
      
  } 
  else { // exclusive case, only one calculation needed
    vector<double> weights;
    double sum = 0., w = 0.;
    for(unsigned int p=0; p<m_perms[njets].at(nbtag).size(); p++) {
      w = trfWeight(m_perms[njets].at(nbtag).at(p),calib);
      sum+=w;
      m_permsWeight.at(nbtag).push_back(w);
      m_permsSumWeight.at(nbtag).push_back(sum);
    }
    m_trfRes[calib].trfwsys_ex[syst].at(nbtag) = sum;
    return sum;
  }
  return 1.;
}

void TRFinterface::getTRFweightsForSyst(string calib, unsigned int limit, vector<vector<double> > &trf_weight_ex, 
					vector<vector<double> > &trf_weight_in, unsigned int pdgid_EV, bool isUpVar)
{
  trf_weight_ex.clear(), trf_weight_in.clear();
  trf_weight_ex.resize(getNumEV(pdgid_EV,calib));
  trf_weight_in.resize(getNumEV(pdgid_EV,calib));
  // need to give iev+1 as EV as 0 is nominal
  for(unsigned int iev=0; iev < getNumEV(pdgid_EV,calib); iev++) {
    if(isUpVar) getTRFweights(calib, limit, trf_weight_ex.at(iev), trf_weight_in.at(iev), pdgid_EV, iev+1);
    else getTRFweights(calib, limit, trf_weight_ex.at(iev), trf_weight_in.at(iev), pdgid_EV, -(iev+1));
  }
}

double TRFinterface::getTRFweightWithPermRW(string calib, unsigned int nbtag, bool isIncl, unsigned int pdgid_EV, int eigenv, bool extrap)
{
  if(m_debug > 3) cout << "getTRFweightWithPermRW: btag = " << nbtag << "  incl = " << isIncl  << "  pdgid = " << pdgid_EV << "  ev = " << eigenv << "  calib = " << calib << endl;
  // TRF weight, then permutation RW and tag bins RW
  double weight = getTRFweight(calib, nbtag, isIncl, pdgid_EV, eigenv, extrap);
  if(m_rwSystForPerm) {
    if(isIncl) {
      weight *= getPermutationRW(calib, true, nbtag, calib, pdgid_EV, eigenv, extrap);
      if(m_rwSystForTagBins) weight *= getTagBinsRW(calib, true, nbtag, calib, pdgid_EV, eigenv, extrap);
    } 
    else {
      weight *= getPermutationRW(calib, false, nbtag, calib, pdgid_EV, eigenv, extrap);
      if(m_rwSystForTagBins) weight *= getTagBinsRW(calib, false, nbtag, calib, pdgid_EV, eigenv, extrap);
    }
  }
  return weight;
}

double TRFinterface::getTRFextrapUncertainty(string calib, unsigned int nbtag, bool isIncl, bool isUp, unsigned int pdgid_EV)
{
  // TRF weight, then permutation RW and tag bins RW
  int eigenv = 0;
  if(isUp) eigenv = 1;
  else eigenv = -1;
  double weight = getTRFweight(calib, nbtag, isIncl, pdgid_EV, eigenv, true);
  if(m_rwSystForPerm) {
    if(isIncl) {
      weight *= getPermutationRW(calib, true, nbtag, calib, pdgid_EV, eigenv, true);
      if(m_rwSystForTagBins) weight *= getTagBinsRW(calib, true, nbtag, calib, pdgid_EV, eigenv, true);
    } 
    else {
      weight *= getPermutationRW(calib, false, nbtag, calib, pdgid_EV, eigenv, true);
      if(m_rwSystForTagBins) weight *= getTagBinsRW(calib, false, nbtag, calib, pdgid_EV, eigenv, true);
    }
  }
  return weight;
}

void TRFinterface::getTRFextrapUncertainties(std::string calib, unsigned int limit, std::vector<double> &trf_weight_ex, std::vector<double> &trf_weight_in, bool isUp, unsigned int pdgid_EV)
{
  if(isUp) getTRFweights(calib, limit, trf_weight_ex, trf_weight_in, pdgid_EV, 1, true);
  else getTRFweights(calib, limit, trf_weight_ex, trf_weight_in, pdgid_EV, -1, true);
}

void TRFinterface::setTRFweights(string calib, vector<double> &trfw_ex, vector<double> &trfw_in)
{
  // per default check 1 b-tags
  double tweight = getTRFweight(calib, 1, true);
  if(fabs(tweight-trfw_in.at(1)) > 1e-5) {
    cout << "[31mIt seems that the calibration you try to set " << calib << " does not correspond to the one in the configuration file, please check it\n"
	 << "This is important as you need to calculated the correct probabilities for each permutation and tag bins configuration.[0m" << endl;
    exit(-1);
  }
  
  m_trfRes[calib].trfwsys_ex[0].clear(), m_trfRes[calib].trfwsys_in[0].clear();
  m_trfRes[calib].trfwsys_ex[0] = trfw_ex;
  m_trfRes[calib].trfwsys_in[0] = trfw_in;
  m_trfRes[calib].rwpcals_ex.clear(), m_trfRes[calib].rwpcals_in.clear();
  m_trfRes[calib].rwpcals_ex.resize(trfw_ex.size(),1.), m_trfRes[calib].rwpcals_in.resize(trfw_in.size(),1.);
  m_trfRes[calib].rwtbcals_ex.clear(), m_trfRes[calib].rwtbcals_in.clear();
  m_trfRes[calib].rwtbcals_ex.resize(trfw_ex.size(),1.), m_trfRes[calib].rwtbcals_in.resize(trfw_in.size(),1.);
}

void TRFinterface::setTRFweight(string calib, double weight, bool isIncl, unsigned int nbtag)
{
  // use getTRFweight to set SF and eff and to check the weight and initialize vectors and maps (if inclusive no choice to recalculate to check the weight...)
  double tweight = getTRFweight(calib, nbtag, isIncl);
  if(isIncl) {
    m_trfRes[calib].trfwsys_in[0].at(nbtag) = weight;
    if(fabs(tweight-weight) > 1e-5)
      cout << "[31mIt seems that the calibration you try to set " << calib << " does not correspond to the one in the configuration file, please check it\n"
	   << "This is important as you need to calculated the correct probabilities for each permutation and tag bins configuration.[0m" << endl;
  } 
  else {
    m_trfRes[calib].trfwsys_ex[0].at(nbtag) = weight;
    if(fabs(tweight-weight) > 1e-5)
      cout << "[31mIt seems that the calibration you try to set " << calib << " does not correspond to the one in the configuration file, please check it\n"
	   << "This is important as you need to calculated the correct probabilities for each permutation and tag bins configuration.[0m" << endl;
  }
}

void TRFinterface::getAllEff(string calib)
{
  if(!m_trfRes[calib].eff.empty()) return;

  vector<unsigned int> limap = (m_calibMap[calib].nmaps == 1) ? vector<unsigned int>(m_imap.size(),0) : m_imap;

  for(unsigned int j=0; j<m_pt.size(); j++) {
    if(m_debug > 7) cout << "nbre d'OP = " << BtagOP::get_nOP(m_calibMap[calib].jetCalAlg) << " pour calib = " << calib << "  inv calib = " << m_calibMap[calib].jetCalAlgInv << endl;
    
    unsigned int rmops = 1;
    if(!m_calibMap[calib].isCont) rmops = 2;
    // should be -2 in cumulative case -> real number of OP and not number of bins in that case, number of bins in continuous case
    for(unsigned int op = 0; op < BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-rmops; op++) {
      m_trfRes[calib].eff[j][op] = getEff(m_pt.at(j), m_eta.at(j), m_pdg.at(j), op, calib, limap.at(j));
      if(m_debug > 5) {
  	double opval = (m_calibMap[calib].isCont==true) ? BtagOP::get_OP(op,m_calibMap[calib].jetCalAlg) : BtagOP::get_OP(op+1,m_calibMap[calib].jetCalAlg) ;
  	cout << "[34meff = " << m_trfRes[calib].eff[j][op] << "  pour tagw = " << m_tagw.at(j) << "  op = " << opval << "  OP = " << op << "  pdg = " << m_pdg.at(j)
	     << "  map = " << limap.at(j) << "[0m" << endl;
      }
    }
  }
}

void TRFinterface::getAllSF(string calib, unsigned int pdg_ev, int ev, bool extrap)
{
  m_trfRes[calib].SF.clear();
  vector<unsigned int> limap = (m_calibMap[calib].nmaps == 1 || m_calibMap[calib].isCont==false) ? vector<unsigned int>(m_imap.size(),0) : m_imap;
  for(unsigned int j=0; j<m_pt.size(); j++) {
    unsigned int rmops = 1;
    if(!m_calibMap[calib].isCont) rmops = 2;
    for(unsigned int op = 0; op < BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-rmops; op++) {
      if(extrap) {
	if(pdg_ev == 999) { // expected as recommendation is to correlate extrapolation uncertainties
	  m_trfRes[calib].SF[j][op] = getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), op, calib, limap.at(j), ev, true); // ev has to be >0 for up variation and <0 for the down one
	} 
	else {
	  if(abs(m_pdg.at(j)) != pdg_ev) m_trfRes[calib].SF[j][op] = getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), op, calib);
	  else m_trfRes[calib].SF[j][op] = getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), op, calib, limap.at(j), ev, true); // ev has to be >0 for up variation and <0 for the down one
	}
      } 
      else {
	if(ev != 0 && (abs(m_pdg.at(j)) == pdg_ev || (abs(m_pdg.at(j)) == 15 && pdg_ev == 4)))
	  m_trfRes[calib].SF[j][op] = getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), op, calib, limap.at(j), ev);
	else m_trfRes[calib].SF[j][op] = getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), op, calib, limap.at(j));
      }
      if(m_debug > 5) {
  	double opval = (m_calibMap[calib].isCont==true) ? BtagOP::get_OP(op,m_calibMap[calib].jetCalAlg) : BtagOP::get_OP(op+1,m_calibMap[calib].jetCalAlg) ;
  	cout << "[31mSF = " << m_trfRes[calib].SF[j][op] << "  pour tagw = " << m_tagw.at(j) << "  op = " << opval << "  OP = " << op << "  pdg = " << m_pdg.at(j) << "[0m" << endl;
      }
    }
  }
}

double TRFinterface::getEvtSF(string calib, unsigned int pdgid_EV, int eigenv, bool extrap)
{
  double SF = 1.;
  vector<unsigned int> limap = (m_calibMap[calib].nmaps == 1 || m_calibMap[calib].isCont==false) ? vector<unsigned int>(m_imap.size(),0) : m_imap;
  if(m_calibMap[calib].isCont) {
    for(unsigned int j=0; j<m_pt.size(); j++) {
      if(extrap) {
        if(pdgid_EV == 999) { // expected as recommendation is to correlate extrapolation uncertainties
	  SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_tagw.at(j), calib, limap.at(j), eigenv, true); // ev has to be >0 for up variation and <0 for the down one
        } 
	else {
	  if(abs(m_pdg.at(j)) != pdgid_EV) SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_tagw.at(j), calib, limap.at(j));
	  else SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_tagw.at(j), calib, limap.at(j), eigenv, true); // ev has to be >0 for up variation and <0 for the down one
	}
      } 
      else {
	if(eigenv != 0 && (abs(m_pdg.at(j)) == pdgid_EV || (abs(m_pdg.at(j)) == 15 && pdgid_EV == 4)))
	  SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_tagw.at(j), calib, limap.at(j), eigenv);
	else SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_tagw.at(j), calib, limap.at(j));
      }
    }
    return SF;
  } 
  else {
    vector<unsigned int> limap = (m_calibMap[calib].nmaps == 1) ? vector<unsigned int>(m_imap.size(),0) : m_imap;
    for(unsigned int j=0; j<m_pt.size(); j++) {
      if(m_tagw.at(j) > m_OP) {
	if(extrap) {
	  if(pdgid_EV == 999) { // expected as recommendation is to correlate extrapolation uncertainties
	    SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, 0, eigenv, true); // ev has to be >0 for up variation and <0 for the down one
	  } 
	  else {
	    if(abs(m_pdg.at(j)) != pdgid_EV) SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib);
	    else SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, 0, eigenv, true); // ev has to be >0 for up variation and <0 for the down one
	  }
	} 
	else {
	  if(eigenv != 0 && (abs(m_pdg.at(j)) == pdgid_EV || (abs(m_pdg.at(j)) == 15 && pdgid_EV == 4)))
	    SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, 0, eigenv);
	  else SF *= getSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib);
	}	
      } 
      else {
	if(extrap) {
	  if(pdgid_EV == 999) { // expected as recommendation is to correlate extrapolation uncertainties
	    SF *= getIneffSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, limap.at(j), eigenv, true); // ev has to be >0 for up variation and <0 for the down one
	  } 
	  else {
	    if(abs(m_pdg.at(j)) != pdgid_EV) SF *= getIneffSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, limap.at(j));
	    else SF *= getIneffSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, limap.at(j), eigenv, true); // ev has to be >0 for up variation and <0 for the down one
	  }
	} 
	else {
	  if(eigenv != 0 && (abs(m_pdg.at(j)) == pdgid_EV || (abs(m_pdg.at(j)) == 15 && pdgid_EV == 4)))
	    SF *= getIneffSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, limap.at(j), eigenv);
	  else SF *= getIneffSF(m_pt.at(j), m_eta.at(j), m_pdg.at(j), m_calibMap[calib].OPbin-1, calib, limap.at(j));
	}
      }
    }
    return SF;
  }
}

vector<vector<bool> > TRFinterface::generatePermutations(int njets, int tags, int start)
{
  vector<vector<bool> > perm;
  vector<vector<bool> > temp_perm;
  if(tags==0){
    vector<bool> tags(njets,false);
    perm.push_back(tags);
  } 
  else if(tags == njets) {
    vector<bool> tags(njets,true);
    perm.push_back(tags);    
  } 
  else {
    for(int i=start; i<njets;i++){
      temp_perm = generatePermutations(njets,tags-1,i+1);
      for(unsigned int j=0; j<temp_perm.size(); j++){
        temp_perm.at(j).at(i)=true;
        perm.push_back(temp_perm.at(j));
      }
    }
  }
  return perm;
}

double TRFinterface::trfWeight(const vector<bool> &tags, string calib)
{
  double weight = 1;
  for (unsigned int j=0; j<tags.size();j++) {

    double eff = 0., trf = 0.;
    unsigned int binBtagCut = BtagOP::getLCbin(m_OP,m_calibMap[calib].jetCalAlg);

    // cumulative case
    if(!m_calibMap[calib].isCont) {
      trf = m_trfRes[calib].SF[j][binBtagCut-1] * m_trfRes[calib].eff[j][binBtagCut-1]; // -1 due to 0 not being a real OP
    }

    // continuous case
    else {
      for(unsigned int itagw = binBtagCut; itagw < BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-1; itagw++) {
      	trf +=  m_trfRes[calib].SF[j][itagw] * m_trfRes[calib].eff[j][itagw];
      	eff += m_trfRes[calib].eff[j][itagw];
      }
    }

    // checks for closure -> to be commented when validated, (to be set to true in constructor)
    if(m_checkClosure && m_calibMap[calib].isCont) {
      double ctrf = 0., ceff = 0.;
      for(unsigned int itagw = 0; itagw < binBtagCut; itagw++) {
  	ctrf +=  m_trfRes[calib].SF[j][itagw] * m_trfRes[calib].eff[j][itagw];
  	ceff +=  m_trfRes[calib].eff[j][itagw];
      }
      
      if(fabs(trf+ctrf-1) > 2e-2 || fabs(eff+ceff-1) > 1e-5) {
  	cout << "  with continuous:  eff = " << eff << "  TRF = " << trf << "  UNtag:  eff = " << ceff 
  	     << "  TRF = " << ctrf << "  sum = " << trf+ctrf << "  sum MC eff = " << eff+ceff << "  label = " << m_pdg.at(j)
  	     << "  pt = " << m_pt.at(j) << "  eta = " << m_eta.at(j) << endl;
  	cout << "fabs(trf+ctrf) > 1e-5 = " << 	(fabs(trf+ctrf) > 1e-5) << "  (eff+ceff) > 1e-5 =  " << ((eff+ceff) > 1e-5) << endl;
      }
    }
    
    if(trf>1.) {
      cout << "[31mCaution trf > 1. maps not carefully checked ?[0m" << endl;
      trf = 1.;
    }
    
    if(tags.at(j)) weight *= trf;
    else weight *= (1.-trf);
    
  } // end loop over jets
  return weight;
}

void TRFinterface::chooseTagPermutation(string calib, unsigned int nbtag, vector<vector<bool> > &trf_chosen_perm_ex, vector<vector<bool> > &trf_chosen_perm_in)
{
  unsigned int njets = m_pt.size();
  unsigned int limit = (njets > 7) ? 8 : njets+1;
  unsigned int max = (njets < nbtag+1) ? limit : nbtag+1;

  m_trfRes[calib].perm_ex.clear(), m_trfRes[calib].perm_ex.resize(nbtag+1);
  m_trfRes[calib].perm_in.clear(), m_trfRes[calib].perm_in.resize(nbtag+1);
  trf_chosen_perm_ex.resize(nbtag+1);
  trf_chosen_perm_in.resize(nbtag+1);

  for(unsigned int i=0; i<max; i++) { // need +1 as 0 is included
    trf_chosen_perm_ex.at(i) = chooseTagPermutation(calib,i,false);
    trf_chosen_perm_in.at(i) = chooseTagPermutation(calib,i,true);
  }
}

vector<bool> TRFinterface::chooseTagPermutation(string calib, unsigned int nbtag, bool isIncl) // const vector<vector<bool> > &perms, const vector<double> &weights)
{
  if(m_debug > 7) cout << "size permprob EX = " << m_trfRes[calib].permprob_ex.size() << "  IN = " << m_trfRes[calib].permprob_in.size() << "  calib = " << calib << endl;
  unsigned int njets = m_pt.size();
  vector<double> incl;
  vector<pair<unsigned int, unsigned int> > trackPerm;
  double sum = 0;
  if(isIncl) {
    for(unsigned int itag=nbtag; itag < m_permsWeight.size(); itag++) {
      for(unsigned int ip = 0; ip < m_permsWeight.at(itag).size(); ip++) {
  	sum += m_permsWeight.at(itag).at(ip);
  	incl.push_back(sum);
  	trackPerm.push_back(make_pair(itag,ip));
      }
    }
  } 
  else { // in exclusive case
    sum = m_permsSumWeight.at(nbtag).back();
    incl = m_permsSumWeight.at(nbtag);
    for(unsigned int ip = 0; ip < m_permsSumWeight.at(nbtag).size(); ip++) trackPerm.push_back(make_pair(nbtag,ip));
  }

  if(m_debug > 8) { // check the total proba of permutation (should be 1...)
    double sp=0.;
    for(unsigned int ip = 0; ip < incl.size(); ip++) {
      cout << "[36mpermutation " << ip << "  picked, proba = " << m_permsWeight.at(trackPerm.at(ip).first).at(trackPerm.at(ip).second)/sum << "[0m" << endl;
      sp += m_permsWeight.at(trackPerm.at(ip).first).at(trackPerm.at(ip).second)/sum;
    }
    cout << "[31mSum proba = " << sp << "[0m" << endl;
  }

  double theX = m_rand.Uniform(sum);
  for(unsigned int ip=0; ip < incl.size(); ip++) {
    if(incl.at(ip) >= theX) {
      if(m_debug > 7) cout << "[34mpermutation " << ip 
			   << "  picked, proba = " << m_permsWeight.at(trackPerm.at(ip).first).at(trackPerm.at(ip).second)/sum 
			   << "  permw = " << m_permsWeight.at(trackPerm.at(ip).first).at(trackPerm.at(ip).second)
			   << "  for sum = " << sum
			   << "  (seed = " << m_rand.GetSeed() << ")[0m" << endl;
      if(isIncl) {
	m_trfRes[calib].perm_in.at(nbtag) = m_perms[njets].at(trackPerm.at(ip).first).at(trackPerm.at(ip).second);
	m_trfRes[calib].permprob_in.at(nbtag) = m_permsWeight.at(trackPerm.at(ip).first).at(trackPerm.at(ip).second) / m_trfRes[calib].trfwsys_in[0].at(nbtag);
      } 
      else {
	m_trfRes[calib].perm_ex.at(nbtag) = m_perms[njets].at(trackPerm.at(ip).first).at(trackPerm.at(ip).second);
	m_trfRes[calib].permprob_ex.at(nbtag) = m_permsWeight.at(trackPerm.at(ip).first).at(trackPerm.at(ip).second) / m_trfRes[calib].trfwsys_ex[0].at(nbtag);
      }
      if (m_debug > 5) cout << "Size of the vector: " << m_perms[njets].at(trackPerm.at(ip).first).at(trackPerm.at(ip).second).size() << endl;
      return m_perms[njets].at(trackPerm.at(ip).first).at(trackPerm.at(ip).second);
    }
  }
  vector<bool> tmp;
  return tmp;
}

void TRFinterface::setAllPermutations(std::string calib, vector<vector<bool> > &tagconf_ex, vector<vector<bool> > &tagconf_in)
{
  m_trfRes[calib].perm_ex.resize(tagconf_ex.size()),  m_trfRes[calib].perm_in.resize(tagconf_in.size());
  m_trfRes[calib].permprob_ex.resize(tagconf_ex.size()),  m_trfRes[calib].permprob_in.resize(tagconf_in.size());
  for(unsigned int itc=0; itc < tagconf_ex.size(); itc++) {
    setPermutation(calib, tagconf_ex.at(itc), false, itc);
    setPermutation(calib, tagconf_in.at(itc), true, itc);
  }
}

void TRFinterface::setPermutation(string calib, vector<bool> &tagconf, bool isIncl, unsigned int nbtag)
{
  if(isIncl) {
    if(m_trfRes[calib].perm_in.size() < nbtag) m_trfRes[calib].perm_in.resize(nbtag+1);
    m_trfRes[calib].perm_in.at(nbtag) = tagconf;
    double permw = trfWeight(tagconf,calib);
    m_trfRes[calib].permprob_in.at(nbtag) = permw /  m_trfRes[calib].trfwsys_in[0].at(nbtag);
    m_trfRes[calib].rwpcals_in.at(nbtag) = getPermutationRW(m_calibName,true,nbtag,calib);
    if(m_debug > 5)
      cout << "AF in perm RW = " << m_trfRes[calib].rwpcals_in.at(nbtag) << "  et permprob = " << m_trfRes[calib].permprob_in.at(nbtag) << "  trf = " << m_trfRes[calib].trfwsys_in[0].at(nbtag) << endl;
  } 
  else {
    if(m_trfRes[calib].perm_ex.size() < nbtag) m_trfRes[calib].perm_ex.resize(nbtag+1);
    m_trfRes[calib].perm_ex.at(nbtag) = tagconf;
    double permw = trfWeight(tagconf,calib);
    m_trfRes[calib].permprob_ex.at(nbtag) = permw /  m_trfRes[calib].trfwsys_ex[0].at(nbtag);
    m_trfRes[calib].rwpcals_ex.at(nbtag) = getPermutationRW(m_calibName,false,nbtag,calib);
    if(m_debug > 5) cout << "AF ex perm RW = " << m_trfRes[calib].rwpcals_ex.at(nbtag) << "  et  permprob = " << m_trfRes[calib].permprob_ex.at(nbtag) << endl;
  }
}

void TRFinterface::getAllPermutationsRW(string calib, vector<double> &prw_ex, vector<double> &prw_in)
{
  if(m_trfRes[calib].permprob_ex.size() == 0 || m_trfRes[calib].perm_ex.size() == 0 || m_trfRes[calib].permprob_in.size() == 0 ||  m_trfRes[calib].perm_in.size() == 0) {
    cout << "[31mNo tag bins seem to have been give, please use chooseTagPermutation or setTagPermutation[0m" << endl;
    exit(-1);
  }
  prw_ex.resize(m_trfRes[calib].perm_ex.size()), prw_in.resize(m_trfRes[calib].perm_in.size());
  for(unsigned int ib = 0; ib<m_trfRes[calib].perm_ex.size(); ib++) {
    prw_ex.at(ib) = m_trfRes[calib].rwpcals_ex.at(ib);
    prw_in.at(ib) = m_trfRes[calib].rwpcals_in.at(ib);
  }
}

double TRFinterface::getPermutationRW(string calib, bool isIncl, unsigned int nbtag, string ncalib, unsigned int pdgid_EV, int eigenv, bool extrap)
{
  double w = 1.;

  if(((pdgid_EV == 999 && extrap == false) || eigenv==0) && calib == ncalib) return 1.;
  int syst = getSystId(pdgid_EV,eigenv, extrap);
  if(nbtag < m_pt.size() && ((!isIncl && m_trfRes[calib].permprob_ex.at(nbtag) == 0.) || (isIncl && m_trfRes[calib].permprob_in.at(nbtag) == 0.)) )  {
    cout << "nbtag = " << nbtag << endl;
    cout << "[31mPlease use the function setAllPermutations before using the RW to initialize correctly the nominal for calib = " << calib << "[0m" << endl;
    exit(-1);
  }

  if(nbtag > m_pt.size()) return 1.;
  
  if(isIncl) {
    w = trfWeight(m_trfRes[calib].perm_in.at(nbtag),ncalib);

    if(m_debug > 7)
      cout << "nom proba = " << m_trfRes[calib].permprob_in.at(nbtag) << "  nbtag = " << nbtag << "  from " << trfWeight(m_trfRes[calib].perm_in.at(nbtag),calib) 
	   << "  and " << m_trfRes[calib].trfwsys_in[syst].at(nbtag) << endl
	   << "syst proba = " << w/m_trfRes[ncalib].trfwsys_in[syst].at(nbtag) << "  from " << w << " (or " << trfWeight(m_trfRes[ncalib].perm_in.at(nbtag),ncalib) << ")"
	   << "  and " << m_trfRes[ncalib].trfwsys_in[syst].at(nbtag) << endl
    	   << "ratio = " << w/m_trfRes[ncalib].trfwsys_in[syst].at(nbtag) / m_trfRes[calib].permprob_in.at(nbtag) << endl
	   << "Perm IN " << nbtag << " btag, calib rw = " <<  m_trfRes[calib].rwpcals_in.at(nbtag) << "  and new cal = " << m_trfRes[ncalib].rwpcals_in.at(nbtag) << endl;

    return w/m_trfRes[ncalib].trfwsys_in[syst].at(nbtag)/m_trfRes[calib].permprob_in.at(nbtag) * m_trfRes[calib].rwpcals_in.at(nbtag);

  } 
  else {
    w = trfWeight(m_trfRes[calib].perm_ex.at(nbtag),ncalib);

    if(m_debug > 7)
      cout << "[34mnom proba = " << m_trfRes[calib].permprob_ex.at(nbtag) << "  nbtag = " << nbtag << "[0m" << endl
	   << "syst proba = " << w/m_trfRes[ncalib].trfwsys_ex[syst].at(nbtag) << endl
	   << "ratio = " << w/m_trfRes[ncalib].trfwsys_ex[syst].at(nbtag) / m_trfRes[calib].permprob_ex.at(nbtag)
	   << "  et tot = " << w/m_trfRes[ncalib].trfwsys_ex[syst].at(nbtag)/m_trfRes[calib].permprob_ex.at(nbtag) * m_trfRes[calib].rwpcals_ex.at(nbtag) << endl
	   << "Perm EX " << nbtag << " btag, calib rw = " <<  m_trfRes[calib].rwpcals_ex.at(nbtag) << "  and new cal = " << m_trfRes[ncalib].rwpcals_ex.at(nbtag) << endl;

    return w/m_trfRes[ncalib].trfwsys_ex[syst].at(nbtag)/m_trfRes[calib].permprob_ex.at(nbtag) * m_trfRes[calib].rwpcals_ex.at(nbtag);
  }
}

void TRFinterface::chooseTagBins(string calib, vector<vector<int> > &trf_bin_ex, vector<vector<int> > &trf_bin_in)
{
  m_trfRes[calib].tbins_ex.clear();
  m_trfRes[calib].tbins_in.clear();
  m_trfRes[calib].tbins_ex.resize( m_trfRes[calib].trfwsys_ex[0].size());
  m_trfRes[calib].tbins_in.resize( m_trfRes[calib].trfwsys_in[0].size());
  m_trfRes[calib].binsprob_ex.clear();
  m_trfRes[calib].binsprob_in.clear();
  m_trfRes[calib].binsprob_ex.resize( m_trfRes[calib].trfwsys_ex[0].size());
  m_trfRes[calib].binsprob_in.resize( m_trfRes[calib].trfwsys_in[0].size());

  if(m_trfRes[calib].perm_ex.size() != m_trfRes[calib].perm_in.size()) cout << "Different sizes in exclusive and inclusive permutation choices" << endl;

  if(trf_bin_ex.size() != 0) trf_bin_ex.clear(), trf_bin_in.clear();

  for(unsigned int ic=0; ic<m_trfRes[calib].perm_ex.size(); ic++) {
    trf_bin_ex.push_back(chooseTagBins(calib, m_trfRes[calib].perm_ex.at(ic), false, ic));
    trf_bin_in.push_back(chooseTagBins(calib, m_trfRes[calib].perm_in.at(ic), true, ic));
  }
}

vector<int> TRFinterface::chooseTagBins(string calib, vector<bool> &tagconf, bool isIncl, unsigned int nbtag)
{
  if(m_trfRes[calib].binsprob_ex.size() < nbtag && !isIncl) {
    m_trfRes[calib].tbins_ex.clear();
    m_trfRes[calib].tbins_ex.resize(m_trfRes[calib].trfwsys_ex[0].size());
    m_trfRes[calib].binsprob_ex.clear();
    m_trfRes[calib].binsprob_ex.resize( m_trfRes[calib].trfwsys_ex[0].size());
  } 
  else if(m_trfRes[calib].binsprob_in.size() < nbtag && isIncl) {
    m_trfRes[calib].tbins_in.clear();
    m_trfRes[calib].tbins_in.resize(m_trfRes[calib].trfwsys_ex[0].size());
    m_trfRes[calib].binsprob_in.clear();
    m_trfRes[calib].binsprob_in.resize( m_trfRes[calib].trfwsys_in[0].size());
  }

  if(m_calibMap[calib].isCont) return chooseTagBins_cont(calib, tagconf, isIncl, nbtag);
  else return chooseTagBins_cum(calib, tagconf, isIncl, nbtag);
}

vector<int> TRFinterface::chooseTagBins_cum(string calib, vector<bool> &tagconf, bool isIncl, unsigned int nbtag)
{
  vector<int> btagops;
  unsigned int binBtagCut = BtagOP::getLCbin(m_OP,m_calibMap[calib].jetCalAlg);
  vector<double> incl;
  double prob = 1.;

  for(unsigned int j=0; j<tagconf.size(); j++) {
    if(tagconf.at(j)) { // tagged jet
      double sum=0.;
      incl.clear();
      // attention aux OP continuous et cumulative -> pas du tout same meaning...
      for(int iop = (int)m_trfRes[calib].eff[j].size()-1; iop >= (int)binBtagCut-1; iop--) {
  	if(!m_calibMap[calib].useSF) sum = m_trfRes[calib].eff[j][iop];
  	else sum = m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
  	incl.push_back(sum);
      }

      if(m_debug > 9) {
	cout << "size of incl = " << incl.size() << endl;
	for(unsigned int ip=0; ip<incl.size(); ip++) cout << "num " << ip << " = " << incl.at(ip) << endl;
	double sp=0.;
	for(unsigned int k=0; k < incl.size(); k++) {
	  double valm1 = 0.;
	  if(k!=0) valm1 = incl.at(k-1);
	  cout << "[36mpermutation TAG " << k << "  picked, proba = " << (incl.at(k)-valm1)/sum << "[0m" << endl;
	  sp += (incl.at(k)-valm1)/sum;
	}
	cout << "[31mSum proba = " << sp << " (pdg = " << m_pdg.at(j) << "[0m" << endl;
      }

      double theX = m_rand.Uniform(sum);
      for(unsigned int k=0; k<incl.size(); k++) {
	double valm1 = 0.;
	if(k!=0) valm1 = incl.at(k-1);
  	if(incl.at(k) >= theX) {
  	  btagops.push_back(BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-2-k);
	  prob *= (incl.at(k)-valm1) / sum;
  	  break;
  	}
      }
    }
    else { // untagged jet
      double sum=0.;
      incl.clear();
      incl.push_back(sum); // fill the "0_0" OP as no real value affected and start the loop at 1
      for(unsigned int iop=0; iop<binBtagCut; iop++) { // need to include the chosen tag cut to have the last MV1 bin of untagged jets filled, start at 0 with cumulative as iop = 0 = first OP
  	// sum = 1 - trf here
  	if(!m_calibMap[calib].useSF) sum = 1 - m_trfRes[calib].eff[j][iop];
  	else sum = 1 - m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
  	incl.push_back(sum);
      }

      if(m_debug > 9) {
	cout << "size of incl = " << incl.size() << endl;
	for(unsigned int ip=0; ip<incl.size(); ip++) cout << "num " << ip << " = " << incl.at(ip) << endl;
	double sp=0.;
	for(unsigned int ip=1; ip < incl.size(); ip++) { // 0 is always first so we can start at 1
	  cout << "prob = " << incl.at(ip) << "  sum = " << sum << endl;
	  cout << "[36mpermutation UNTAG " << ip << "  picked, proba = " << (incl.at(ip)-incl.at(ip-1))/sum << "[0m" << endl;
	  sp += (incl.at(ip)-incl.at(ip-1))/sum;
	}
	cout << "[31mSum proba = " << sp << "[0m" << endl;
      }

      double theX = m_rand.Uniform(sum);
      for(unsigned int k=1; k<incl.size(); k++) {
        if(incl.at(k) >= theX){
  	  btagops.push_back(k-1);
	  prob *= (incl.at(k) - incl.at(k-1)) / sum;
	  if(m_debug > 11) cout << "chosen bin = " << k-1 << "  for k = " << k << "  prob = " << (incl.at(k) - incl.at(k-1)) / sum << endl;
          break;
        }
      }
    }
  }
  if(btagops.size() != tagconf.size()) {
    cout << "chooseTagBins_cum: You should not be here -> wrong size of tag bins vector" << endl;
    exit(-1);
  }

  if(isIncl) {
    m_trfRes[calib].tbins_in.at(nbtag) = btagops;
    m_trfRes[calib].binsprob_in.at(nbtag) = prob;
  } 
  else {
    m_trfRes[calib].tbins_ex.at(nbtag) = btagops;
    m_trfRes[calib].binsprob_ex.at(nbtag) = prob;
  }
  return btagops;
}

vector<int> TRFinterface::chooseTagBins_cont(string calib, vector<bool> &tagconf, bool isIncl, unsigned int nbtag)
{
  vector<int> btagops;
  if(m_debug > 3) cout << "[35mDans cas cont[0m" << endl;
  vector<double> incl, trfop;
  double prob = 1.;
  unsigned int binBtagCut = BtagOP::getLCbin(m_OP,m_calibMap[calib].jetCalAlg);
  for(unsigned int j=0; j<tagconf.size(); j++) {
    if(tagconf.at(j)) { // tagged jet
      double sum = 0.;
      incl.clear();
      trfop.clear();
      for(int iop=BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-2; iop>(int)binBtagCut-1; iop--) {
  	sum += m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
  	incl.push_back(sum);
	trfop.push_back(m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop]);
      }

      if(m_debug > 9) {
	double sp=0;
	for(unsigned int ip=0; ip<incl.size(); ip++) {
	  sp += trfop.at(ip)/sum;
	  cout << "proba = " << trfop.at(ip)/sum << "  pour ip = " << ip << endl;
	}
	cout<< "sum probas = " << sp << "  et sum = " << sum << endl;
      }

      double theX = m_rand.Uniform(sum);
      for(unsigned int k=0; k<incl.size(); k++) {
  	if(incl.at(k) >= theX) {
  	  btagops.push_back(BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-2-k);
	  prob *= trfop.at(k) / sum;
  	  break;
  	}
      }
    }
    else { // untagged jet
      double sum=0.;
      incl.clear();
      trfop.clear();
      for(unsigned int iop=0; iop<binBtagCut; iop++) {
  	sum += m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
  	incl.push_back(sum);
	trfop.push_back(m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop]);
      }

      if(m_debug > 9) {
	double sp=0;
	for(unsigned int ip=0; ip<incl.size(); ip++) {
	  sp += trfop.at(ip)/sum;
	  cout << "proba = " << trfop.at(ip)/sum << "  pour ip = " << ip << endl;
	}
	cout << "sum probas = " << sp << "  et sum = " << sum << endl;
      }

      double theX = m_rand.Uniform(sum);
      for(unsigned int k=0; k<incl.size(); k++) {
  	if(incl.at(k) >= theX) {
  	  btagops.push_back(k);
	  prob *= trfop.at(k) / sum;
  	  break;
  	}
      }
    }
  }
  if(btagops.size() != tagconf.size()) {
    cout << "chooseTagBins_cont: You should not be here -> wrong size of tag bins vector" << endl;
    exit(-1);
  }
  if(isIncl) {
    m_trfRes[calib].tbins_in.at(nbtag) = btagops;
    m_trfRes[calib].binsprob_in.at(nbtag) = prob;
  } 
  else {
    m_trfRes[calib].tbins_ex.at(nbtag) = btagops;
    m_trfRes[calib].binsprob_ex.at(nbtag) = prob;
  }
  return btagops;
}

double TRFinterface::getTagBinsConfProb(string calib, vector<int> &tagws, bool cumToCont)
{
  double prob = 1.;
  unsigned int binBtagCut = BtagOP::getLCbin(m_OP,m_calibMap[calib].jetCalAlg);
  for(unsigned int j=0; j<tagws.size(); j++) {
    double sum = 0;
    double probj = 0;
    if((unsigned int)tagws.at(j) >= binBtagCut) { // tagged
      if(m_calibMap[calib].isCont) {
	for(int iop=BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-2; iop>(int)binBtagCut-1; iop--) {
	  sum += m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
	  if(tagws.at(j) == iop) probj = m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
	  if(cumToCont && tagws.at(j) == (int)BtagOP::get_nOP("LCcumMV1")-2 && iop == (int)BtagOP::get_nOP("LCcumMV1")-2) probj += m_trfRes[calib].eff[j][iop+1] * m_trfRes[calib].SF[j][iop+1];
	}
	prob *= probj / sum;
      } 
      else {
	double prevBinW = 0.;
	// as jets are tagged tags.at(j) >=1, so OP >=0 DECREASING ORDER HERE !!!
	int mOP = m_trfRes[calib].eff[j].size();
	if(m_calibMap[calib].useSF) {
	  if(tagws.at(j) != mOP) prevBinW =  m_trfRes[calib].eff[j][tagws.at(j)] * m_trfRes[calib].SF[j][tagws.at(j)];
	  prob *= (m_trfRes[calib].eff[j][tagws.at(j)-1] * m_trfRes[calib].SF[j][tagws.at(j)-1] - prevBinW) /  (m_trfRes[calib].eff[j][binBtagCut-1] * m_trfRes[calib].SF[j][binBtagCut-1]);
	} 
	else {
	  if(tagws.at(j) != mOP) prevBinW =  m_trfRes[calib].eff[j][tagws.at(j)];
	  prob *= (m_trfRes[calib].eff[j][tagws.at(j)-1] - prevBinW) /  m_trfRes[calib].eff[j][binBtagCut-1];
	}
	if(m_debug > 11)
	  cout << "cum tagged: tag bin = " << tagws.at(j) << "  probj = " << m_trfRes[calib].eff[j][tagws.at(j)-1] * m_trfRes[calib].SF[j][tagws.at(j)-1]
	       << "  sum = " << m_trfRes[calib].eff[j][binBtagCut-1] * m_trfRes[calib].SF[j][binBtagCut-1]
	       << "  prob = " <<  m_trfRes[calib].eff[j][tagws.at(j)-1] * m_trfRes[calib].SF[j][tagws.at(j)-1] /  m_trfRes[calib].eff[j][binBtagCut-1] * m_trfRes[calib].SF[j][binBtagCut-1] << endl;
      }
    } 
    else { // untagged
      if(m_calibMap[calib].isCont) {
	for(unsigned int iop=0; iop<binBtagCut; iop++) {
	  sum += m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
	  if((unsigned int)tagws.at(j) == iop) probj = m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
	}
	prob *= probj / sum;
      } 
      else {
	double prevBinW = 0.;
	if(m_calibMap[calib].useSF) {
	  if(tagws.at(j) != 0) prevBinW = 1 - m_trfRes[calib].eff[j][tagws.at(j)-1] *  m_trfRes[calib].SF[j][tagws.at(j)-1];
	  prob *= ((1 - m_trfRes[calib].eff[j][tagws.at(j)] *  m_trfRes[calib].SF[j][tagws.at(j)]) - prevBinW) / 
	    (1 - m_trfRes[calib].eff[j][binBtagCut-1] * m_trfRes[calib].SF[j][binBtagCut-1] );
	} 
	else {
	  if(tagws.at(j) != 0) prevBinW = 1 - m_trfRes[calib].eff[j][tagws.at(j)-1];
	  prob *= ((1 - m_trfRes[calib].eff[j][tagws.at(j)]) - prevBinW) / (1 - m_trfRes[calib].eff[j][binBtagCut-1]);
	}
      }
    }
  }
  return prob;
}

void TRFinterface::setAllTagBins(std::string calib, std::vector<std::vector<double> > &trftagw_ex, std::vector<std::vector<double> > &trftagw_in, bool cumToCont)
{
  m_trfRes[calib].tbins_ex.resize(trftagw_ex.size()),  m_trfRes[calib].tbins_in.resize(trftagw_in.size());
  m_trfRes[calib].binsprob_ex.resize(trftagw_ex.size()),  m_trfRes[calib].binsprob_in.resize(trftagw_in.size());
  for(unsigned int itc=0; itc < trftagw_ex.size(); itc++) {
    setTagBins(calib,trftagw_ex.at(itc),false,itc,cumToCont);
    setTagBins(calib,trftagw_in.at(itc),true,itc,cumToCont);
  }
}

void TRFinterface::setAllTagBins(std::string calib, std::vector<std::vector<int> > &trf_bin_ex, std::vector<std::vector<int> > &trf_bin_in, bool cumToCont)
{
  m_trfRes[calib].tbins_ex.resize(trf_bin_ex.size()),  m_trfRes[calib].tbins_in.resize(trf_bin_in.size());
  m_trfRes[calib].binsprob_ex.resize(trf_bin_ex.size()),  m_trfRes[calib].binsprob_in.resize(trf_bin_in.size());
  for(unsigned int itc=0; itc < trf_bin_ex.size(); itc++) {
    setTagBins(calib,trf_bin_ex.at(itc),false,itc,cumToCont);
    setTagBins(calib,trf_bin_in.at(itc),true,itc,cumToCont);
  }
}

void TRFinterface::setTagBins(string calib, vector<int> &tagbins, bool isIncl, unsigned int nbtag, bool cumToCont)
{
  if(isIncl) {
    if(m_trfRes[calib].tbins_in.size() < nbtag) m_trfRes[calib].tbins_in.resize(nbtag+1), m_trfRes[calib].binsprob_in.resize(nbtag+1);
    m_trfRes[calib].tbins_in.at(nbtag) = tagbins;
    if(calib != m_calibName) m_trfRes[calib].rwtbcals_in.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_in.at(nbtag),cumToCont)/m_trfRes[m_calibName].binsprob_in.at(nbtag);
    if(cumToCont) setAdditionalTagBin(calib,m_trfRes[calib].tbins_in.at(nbtag));
    m_trfRes[calib].binsprob_in.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_in.at(nbtag));
    if(m_debug > 5) cout << "IN rwtb = " << m_trfRes[calib].rwtbcals_in.at(nbtag) << "  binsprob = " << m_trfRes[calib].binsprob_in.at(nbtag) << endl;
  } 
  else {
    if(m_trfRes[calib].tbins_ex.size() < nbtag) m_trfRes[calib].tbins_ex.resize(nbtag+1), m_trfRes[calib].binsprob_ex.resize(nbtag+1);
    m_trfRes[calib].tbins_ex.at(nbtag) = tagbins;
    if(calib != m_calibName) m_trfRes[calib].rwtbcals_ex.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_ex.at(nbtag),cumToCont)/m_trfRes[m_calibName].binsprob_ex.at(nbtag);
    if(cumToCont) setAdditionalTagBin(calib,m_trfRes[calib].tbins_ex.at(nbtag));
    m_trfRes[calib].binsprob_ex.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_ex.at(nbtag));
    if(m_debug > 5) cout << "EX rwtb = " << m_trfRes[calib].rwtbcals_ex.at(nbtag) << "  binsprob = " << m_trfRes[calib].binsprob_ex.at(nbtag) << endl;
  } 
}

void TRFinterface::setTagBins(string calib, vector<double> &tagws, bool isIncl, unsigned int nbtag, bool cumToCont)
{
  if(isIncl) {
    if(m_trfRes[calib].tbins_in.size() < nbtag) m_trfRes[calib].tbins_in.resize(nbtag+1);
    if(m_trfRes[calib].tbins_in.at(nbtag).size() == 0) m_trfRes[calib].tbins_in.at(nbtag).resize(m_pt.size());
    if(m_trfRes[calib].binsprob_in.size() == 0) m_trfRes[calib].binsprob_in.resize(nbtag+1);
    for(unsigned int iw=0; iw<tagws.size(); iw++) m_trfRes[calib].tbins_in.at(nbtag).at(iw) = BtagOP::getLCbin(tagws.at(iw),m_calibMap[calib].jetCalAlg);
    if(calib != m_calibName) m_trfRes[calib].rwtbcals_in.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_in.at(nbtag),cumToCont)/m_trfRes[m_calibName].binsprob_in.at(nbtag);
    if(cumToCont) setAdditionalTagBin(calib,m_trfRes[calib].tbins_in.at(nbtag));
    m_trfRes[calib].binsprob_in.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_in.at(nbtag));
  } 
  else {
    if(m_trfRes[calib].tbins_ex.size() < nbtag) m_trfRes[calib].tbins_ex.resize(nbtag+1);
    if(m_trfRes[calib].tbins_ex.at(nbtag).size() == 0) m_trfRes[calib].tbins_ex.at(nbtag).resize(m_pt.size());
    if(m_trfRes[calib].binsprob_ex.size() == 0) m_trfRes[calib].binsprob_ex.resize(nbtag+1);
    for(unsigned int iw=0; iw<tagws.size(); iw++) m_trfRes[calib].tbins_ex.at(nbtag).at(iw) = BtagOP::getLCbin(tagws.at(iw),m_calibMap[calib].jetCalAlg);
    if(calib != m_calibName) m_trfRes[calib].rwtbcals_ex.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_ex.at(nbtag),cumToCont)/m_trfRes[m_calibName].binsprob_ex.at(nbtag);
    if(cumToCont) setAdditionalTagBin(calib,m_trfRes[calib].tbins_ex.at(nbtag));
    m_trfRes[calib].binsprob_ex.at(nbtag) = getTagBinsConfProb(calib, m_trfRes[calib].tbins_ex.at(nbtag));
  }
}

void TRFinterface::setAdditionalTagBin(string calib, vector<int> &tagbins)
{
  for(unsigned int j=0; j<tagbins.size(); j++) {
    if((unsigned int)tagbins.at(j) == BtagOP::get_nOP("LCcumMV1")-2) {
      double sum = 0.;
      vector<double> incl, trfop;
      for(int iop=BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-2; iop>(int)tagbins.at(j)-1; iop--) {
	sum += m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop];
	incl.push_back(sum);
	trfop.push_back(m_trfRes[calib].eff[j][iop] * m_trfRes[calib].SF[j][iop]);
      }

      if(m_debug > 9) {
	double sp=0;
	for(unsigned int ip=0; ip<incl.size(); ip++) {
	  sp += trfop.at(ip)/sum;
	  cout << "proba = " << trfop.at(ip)/sum << "  pour ip = " << ip << endl;
	}
	cout<< "sum probas = " << sp << "  et sum = " << sum << endl;
      }

      double theX = m_rand.Uniform(sum);
      for(unsigned int k=0; k<incl.size(); k++) {
	if(incl.at(k) >= theX) {
	  tagbins.at(j) = BtagOP::get_nOP(m_calibMap[calib].jetCalAlg)-2-k;
	  break;
	}
      }
    }
  }
}

vector<int> TRFinterface::getTagBins(string calib, bool isIncl, unsigned int nbtag)
{
  if(isIncl) return m_trfRes[calib].tbins_in.at(nbtag);
  else return m_trfRes[calib].tbins_ex.at(nbtag);
}

vector<double> TRFinterface::getTagBinsD(string calib, bool isIncl, unsigned int nbtag)
{
  if(isIncl) return getTagWfromTagBins(calib,m_trfRes[calib].tbins_in.at(nbtag));
  else return getTagWfromTagBins(calib,m_trfRes[calib].tbins_ex.at(nbtag)); 
}

void TRFinterface::getAllTagBins(string calib, vector<vector<int> > &trf_bin_ex, vector<vector<int> > &trf_bin_in)
{
  trf_bin_ex = m_trfRes[calib].tbins_ex;
  trf_bin_in = m_trfRes[calib].tbins_in;
}

void TRFinterface::getAllTagBins(string calib, vector<vector<double> > &trf_bin_ex, vector<vector<double> > &trf_bin_in)
{
  trf_bin_ex.resize(m_trfRes[calib].tbins_ex.size()), trf_bin_in.resize(m_trfRes[calib].tbins_in.size());
  for(unsigned int ic=0; ic<m_trfRes[calib].tbins_ex.size(); ic++) {
    trf_bin_ex.at(ic) = getTagWfromTagBins(calib,m_trfRes[calib].tbins_ex.at(ic));
    trf_bin_in.at(ic) = getTagWfromTagBins(calib,m_trfRes[calib].tbins_in.at(ic));
  }
}

vector<double> TRFinterface::getTagWfromTagBins(string calib, vector<int> &tagbins)
{
  vector<double> tagws(tagbins.size());
  for(unsigned int j=0; j<tagbins.size(); j++) {
    tagws.at(j) = BtagOP::mid_TagW[m_calibMap[calib].jetCalAlg].at(tagbins.at(j));
  }
  return tagws;
}

vector<int> TRFinterface::getTagBinsfromTagW(string calib, vector<double> &tagws)
{
  vector<int> tagbins(tagws.size());
  for(unsigned int j=0; j<tagws.size(); j++) {
    tagbins.at(j) = BtagOP::getLCbin(tagws.at(j),m_calibMap[calib].jetCalAlg);
  }
  return tagbins;
}

void TRFinterface::getAllTagBinsRW(string calib, vector<double> &tbrw_ex, vector<double> &tbrw_in)
{
  if(m_trfRes[calib].binsprob_ex.size() == 0 || m_trfRes[calib].tbins_ex.size() ==0 || m_trfRes[calib].binsprob_in.size() == 0 ||  m_trfRes[calib].tbins_in.size() ==0) {
    cout << "[31mNo tag bins seem to have been give, please use choose(All)TagBins or set(All)TagBins[0m" << endl;
    exit(-1);
  }
  tbrw_ex.resize(m_trfRes[calib].tbins_ex.size()), tbrw_in.resize(m_trfRes[calib].tbins_in.size());
  for(unsigned int ib = 0; ib<m_trfRes[calib].tbins_ex.size(); ib++) {
    tbrw_ex.at(ib) = m_trfRes[calib].rwtbcals_ex.at(ib);
    tbrw_in.at(ib) = m_trfRes[calib].rwtbcals_in.at(ib);
  }
}

double TRFinterface::getTagBinsRW(string calib, bool isIncl, unsigned int nbtag, string ncalib, unsigned int pdgid_EV, int eigenv, bool extrap)
{
  if(((pdgid_EV == 999 && extrap == false) || eigenv == 0) && calib == ncalib) return 1.;

  if(calib == ncalib && !m_calibMap[calib].useSF) return 1.; // did not use SF in tag bin choice... -> no effect on systematics

  bool cumToCont = false;
  if(calib != ncalib)
    if((m_calibMap[calib].isCont && !m_calibMap[ncalib].isCont) || (!m_calibMap[calib].isCont && m_calibMap[ncalib].isCont))
      cumToCont = true;

  if((!isIncl && m_trfRes[calib].binsprob_ex.size() == 0) || (isIncl && m_trfRes[calib].binsprob_in.size() == 0)) {
    cout << "[31mNo tag bins seem to have been give, please use choose(All)TagBins or set(All)TagBins[0m" << endl;
    exit(-1);
  }

  if((!isIncl && m_trfRes[calib].binsprob_ex.at(nbtag) == 0) || (isIncl && m_trfRes[calib].binsprob_in.at(nbtag) == 0)) {
    cout << "[31mPlease use the function setAllTagBins or setTagBins before using the RW to initialize correctly the nominal[0m" << endl;
    exit(-1);
  }

  if(isIncl) {
    double tbw = getTagBinsConfProb(ncalib, m_trfRes[calib].tbins_in.at(nbtag), cumToCont)/m_trfRes[calib].binsprob_in.at(nbtag);
    tbw *= m_trfRes[calib].rwtbcals_in.at(nbtag);
    if(m_debug > 9) cout << "IN rwcal = " << m_trfRes[calib].rwtbcals_in.at(nbtag) << "  and for ncalib = " << m_trfRes[ncalib].rwtbcals_in.at(nbtag) << endl;
    return tbw;

  } 
  else {
    double tbw = getTagBinsConfProb(ncalib, m_trfRes[calib].tbins_ex.at(nbtag), cumToCont)/m_trfRes[calib].binsprob_ex.at(nbtag);
    tbw *= m_trfRes[calib].rwtbcals_ex.at(nbtag); // compared to "old" calib, ex for syst, same as for perm rw
    if(m_debug > 9) cout << "EX rwcal = " << m_trfRes[calib].rwtbcals_ex.at(nbtag) << "  and for ncalib = " << m_trfRes[ncalib].rwtbcals_ex.at(nbtag) << endl;
    return tbw;
  }
}

void TRFinterface::printPermutations()
{
  map<int, vector<vector<vector<bool> > > >::iterator njt=m_perms.begin();
  for(; njt != m_perms.end(); njt++) {
    cout << "nj = " << njt->first << endl;
    for(unsigned int nbt=0; nbt<njt->second.size(); nbt++) {
      cout << "nb = " << nbt << " -> nbre de permutations = " << njt->second.at(nbt).size() << endl;
      for(unsigned int np=0; np<njt->second.at(nbt).size(); np++) {
  	cout << "perm " << np << "  jets: ";
  	for(unsigned int njc=0; njc<njt->second.at(nbt).at(np).size(); njc++) {
  	  cout << njt->second.at(nbt).at(np).at(njc) << "  ";
  	}
  	cout << endl;
      }
    }
  } 
}
