#include "BtaggingTRFandRW/BtagOP.h"

#include <iostream>

std::map<std::string,std::vector<double> > BtagOP::op_TagW = {
  {"EMcumMV2c20",{op_MV2c20_EM_100,op_MV2c20_EM_85,op_MV2c20_EM_77,op_MV2c20_EM_70,op_MV2c20_EM_60,op_MV2c20_EM_00}},
  {"EMcontMV2c20",{op_MV2c20_EM_100,op_MV2c20_EM_85,op_MV2c20_EM_77,op_MV2c20_EM_70,op_MV2c20_EM_60,op_MV2c20_EM_00}},
  {"LCcumMV2c20",{op_MV2c20_100,op_MV2c20_85,op_MV2c20_77,op_MV2c20_70,op_MV2c20_60,op_MV2c20_00}},
  {"LCcontMV2c20",{op_MV2c20_100,op_MV2c20_85,op_MV2c20_77,op_MV2c20_70,op_MV2c20_60,op_MV2c20_00}},
};


std::map<std::string,std::vector<std::string> > BtagOP::op_TagW_str = {
  {"EMcumMV2c20",{op_MV2c20_EM_100_str,op_MV2c20_EM_85_str,op_MV2c20_EM_77_str,op_MV2c20_EM_70_str,op_MV2c20_EM_60_str,op_MV2c20_EM_00_str}},
  {"LCcumMV2c20",{op_MV2c20_100_str,op_MV2c20_85_str,op_MV2c20_77_str,op_MV2c20_70_str,op_MV2c20_60_str,op_MV2c20_00_str}},
  {"EMcontMV2c20",{"continuous"}},
  {"LCcontMV2c20",{"continuous"}},
};

std::map<std::string,double> BtagOP::matchMap_opStr = {
  {op_MV2c20_EM_100_str,op_MV2c20_EM_100},
  {op_MV2c20_EM_85_str,op_MV2c20_EM_85},
  {op_MV2c20_EM_77_str,op_MV2c20_EM_77},
  {op_MV2c20_EM_70_str,op_MV2c20_EM_70},
  {op_MV2c20_EM_60_str,op_MV2c20_EM_60},
  {op_MV2c20_EM_00_str,op_MV2c20_EM_00},
  {op_MV2c20_100_str,op_MV2c20_100},
  {op_MV2c20_85_str,op_MV2c20_85},
  {op_MV2c20_77_str,op_MV2c20_77},
  {op_MV2c20_70_str,op_MV2c20_70},
  {op_MV2c20_60_str,op_MV2c20_60},
  {op_MV2c20_00_str,op_MV2c20_00},
  {"continuous",1.}
};

std::map<std::string,double> BtagOP::matchMap_opEffStr = {
  {eff_MV2c20_100_str,op_MV2c20_100},
  {eff_MV2c20_85_str,op_MV2c20_85},
  {eff_MV2c20_77_str,op_MV2c20_77},
  {eff_MV2c20_70_str,op_MV2c20_70},
  {eff_MV2c20_60_str,op_MV2c20_60},
  {eff_MV2c20_00_str,op_MV2c20_00},
};

std::map<std::string,std::vector<double> > BtagOP::setMidTagW()
{
  std::map<std::string,std::vector<double> > tempMap;
  std::map<std::string,std::vector<double> >::iterator it = op_TagW.begin();
  for(; it != op_TagW.end(); it++) {
    std::vector<double> temp(it->second.size()-1);
    for(unsigned int iop = 0; iop < it->second.size()-2; iop++) {
      temp.at(iop) = op_TagW[it->first].at(iop) + (op_TagW[it->first].at(iop+1) - op_TagW[it->first].at(iop))/2.;
    }
    temp.at(it->second.size()-2) = op_TagW[it->first].at(it->second.size()-2) + (1. - op_TagW[it->first].at(it->second.size()-2))/2.;
    tempMap[it->first] = temp;
    // BtagOP::mid_TagW.insert(std::pair<std::string,std::vector<double> >(it->first,temp));
    // int n =  mid_TagW.size();
    // BtagOP::mid_TagW[it->first] = std::vector<double>(it->second.size()-1);
    // mid_TagW.insert(it->first,std::vector<double>(it->second.size()-1));
    // for(unsigned int iop = 0; iop < it->second.size()-2; iop++) {
    //   BtagOP::mid_TagW[it->first].at(iop) = op_TagW[it->first].at(iop) + (op_TagW[it->first].at(iop+1) - op_TagW[it->first].at(iop))/2.;
    // }
    // BtagOP::mid_TagW[it->first].at(it->second.size()-2) = op_TagW[it->first].at(it->second.size()-2) + (1. - op_TagW[it->first].at(it->second.size()-2))/2.;
  }
  return tempMap;
}

std::map<std::string,std::vector<double> > BtagOP::mid_TagW = setMidTagW();

unsigned int BtagOP::getLCbin(double tagw, std::string jetcalalg)
{
  unsigned int bin=-1;
  for(unsigned int i=0; i < op_TagW[jetcalalg].size()-1; i++) {
    if(i == op_TagW[jetcalalg].size()-2 && tagw >= op_TagW[jetcalalg].at(i)) {bin = i; break; }
    else if(tagw >= op_TagW[jetcalalg].at(i) && tagw < op_TagW[jetcalalg].at(i+1)) {
      bin = i;
      break;
    }
  }
  return bin;
}

double BtagOP::get_OP(unsigned int i, std::string jetcalalg)
{
  return op_TagW[jetcalalg].at(i);
}

unsigned int BtagOP::get_nOP(std::string jetcalalg)
{
  return op_TagW[jetcalalg].size();
}

// double BtagOP::get_midTagW(unsigned int i, std::string jetcalalg)
// {
//   return BtagOP::mid_TagW[jetcalalg].at(i);
// }
