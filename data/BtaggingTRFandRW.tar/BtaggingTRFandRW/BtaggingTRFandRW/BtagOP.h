#ifndef BTAGOP_H
#define BTAGOP_H

#include <string>
#include <vector>
#include <map>

namespace BtagOP {
  const double op_MV2c20_EM_00  = 1.5;
  const double op_MV2c20_EM_60  = 0.4496 ;
  const double op_MV2c20_EM_70  = -0.0436 ;
  const double op_MV2c20_EM_77  = -0.4434 ;
  const double op_MV2c20_EM_85  = -0.7887;
  const double op_MV2c20_EM_100 = -2;

  const std::string op_MV2c20_EM_00_str  = "1_0";
  const std::string op_MV2c20_EM_60_str  = "0_4496";
  const std::string op_MV2c20_EM_70_str  = "-0_0436";
  const std::string op_MV2c20_EM_77_str  = "-0_4434";
  const std::string op_MV2c20_EM_85_str  = "-0_7887";
  const std::string op_MV2c20_EM_100_str = "-1_0";

  // for now the same than EM, needs to be changed
  const double op_MV2c20_00  = 1.5;
  const double op_MV2c20_60  = 0.4496;
  const double op_MV2c20_70  = -0.0436;
  const double op_MV2c20_77  = -0.4434;
  const double op_MV2c20_85 = -0.7887;
  const double op_MV2c20_100 = -2;

  const std::string op_MV2c20_00_str  = "1_0";
  const std::string op_MV2c20_60_str  = "0_4496";
  const std::string op_MV2c20_70_str  = "-0_0436";
  const std::string op_MV2c20_77_str  = "-0_4434";
  const std::string op_MV2c20_85_str = "-0_7887";
  const std::string op_MV2c20_100_str = "-1_0";

  const std::string eff_MV2c20_00_str  = "00";
  const std::string eff_MV2c20_60_str  = "60";
  const std::string eff_MV2c20_70_str  = "70";
  const std::string eff_MV2c20_77_str  = "77";
  const std::string eff_MV2c20_85_str = "85";
  const std::string eff_MV2c20_100_str = "100";


  extern std::map<std::string,std::vector<double> > op_TagW;
  extern std::map<std::string,std::vector<std::string> > op_TagW_str;
  extern std::map<std::string,double> matchMap_opStr;
  extern std::map<std::string,double> matchMap_opEffStr;

  extern std::map<std::string,std::vector<double> > mid_TagW;

  // void setMidTagW();
  std::map<std::string,std::vector<double> > setMidTagW();

  // Suppose that per default we are using LC jets -> not foreseen in EM jets case
  unsigned int getLCbin(double tagw, std::string jetcalalg="");
  
  double get_OP(unsigned int i, std::string jetcalalg=""); // {return op_TagW[jetcalalg].at(i);}
  unsigned int get_nOP(std::string jetcalalg=""); // {return op_TagW[jetcalalg].size();}
  // double get_midTagW(unsigned int i, std::string jetcalalg=""); // {return mid_TagW[jetcalalg].at(i);}

}

#endif
