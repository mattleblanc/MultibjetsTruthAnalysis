#ifndef TRFINTERFACE_H
#define TRFINTERFACE_H

#include <map>
#include <string>
#include <TString.h>
#include <TRandom3.h>

#include "CalibrationDataInterface/CalibrationDataInterfaceROOT.h"

class TRFinterface {
public:
  TRFinterface(std::string confFile, double OP=-0.4434, std::string jetCol="AntiKt4EMTopoJets", bool ignoreSF=true, bool checkClosure=false, unsigned int debug=0);
  ~TRFinterface();

  void setReferenceCalib(std::string refCalib) {m_calibName = refCalib;};
  void setTestMode(bool dotest) {m_testMode = dotest;};
  void setUseExtrapApproxErr(bool useExtrapApproxErr) {m_useExtrapApproxErr = useExtrapApproxErr;};

  // by convention ev = 0 -> nominal; !!!! pt has to be in MeV
  double getSF(double pt, double eta, int pdgid, double tagw=0., std::string calib="", unsigned int imap=0, int ev=0, bool extrap=false);
  double getEff(double pt, double eta, int pdgid, double tagw=0., std::string calib="", unsigned int imap=0);

  // Event SF in cut based case
  double getEvtSF(std::string calib, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false);
  double getEvtSF(unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false) {
    return getEvtSF(m_calibName, pdgid_EV, eigenv, extrap);
  };

  // set the jets characteristics of the events and clean the efficiency, SF, ... (=previous event)
  void setJets(std::vector<double> pt, std::vector<double> eta, std::vector<int> pdg, std::vector<double> tagw);
  void setJets(std::vector<double> pt, std::vector<double> eta, std::vector<int> pdg, std::vector<double> tagw, std::vector<unsigned int> imap);

  void setSeed(unsigned int seed);

  // get TRF weight
  double getTRFweight(std::string calib, unsigned int nbtag, bool isInclusive, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false);
  void getTRFweights(std::string calib, unsigned int limit, std::vector<double> &trf_weight_ex, std::vector<double> &trf_weight_in, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false);
  void getTRFweights(unsigned int limit, std::vector<double> &trf_weight_ex, std::vector<double> &trf_weight_in, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false) {
    return getTRFweights(m_calibName, limit, trf_weight_ex, trf_weight_in, pdgid_EV, eigenv, extrap);
  };

  // set TRF weight(s) (only for nominal and check if configuration is correcponding = check one of the TRF weights)
  void setTRFweight(std::string calib, double weight, bool isIncl, unsigned int nbtag);
  void setTRFweights(std::string calib, std::vector<double> &trfw_ex, std::vector<double> &trfw_in);

  // per default rw syst according to permutation and tag bins choice, if not needed (permutation choice and/or tag bins choice not used in the analysis) -> can be set to false
  void setRwSystForPermChoice(bool dorw) {m_rwSystForPerm = dorw;};
  void setRwSystForTagBinsChoice(bool dorw) {m_rwSystForTagBins = dorw;};

  // get vectors of all EV for a given flavour (5, 4 or 0) -> up variations: isUpVar = true, down variations: isUpVar = false; needs to initialize up and down vectors in main
  void getTRFweightsForSyst(std::string calib, unsigned int limit, std::vector<std::vector<double> > &trf_weight_ex, std::vector<std::vector<double> > &trf_weight_in, 
			    unsigned int pdgid_EV, bool isUpVar);
  void getTRFweightsForSyst(unsigned int limit, std::vector<std::vector<double> > &trf_weight_ex, std::vector<std::vector<double> > &trf_weight_in, 
			    unsigned int pdgid_EV, bool isUpVar) {
    return getTRFweightsForSyst(m_calibName, limit, trf_weight_ex, trf_weight_in, pdgid_EV, isUpVar);
  };
  double getTRFweightWithPermRW(std::string calib, unsigned int nbtag, bool isIncl, unsigned int pdgid_EV, int eigenv, bool extrap=false);
  double getTRFweightWithPermRW(unsigned int nbtag, bool isIncl, unsigned int pdgid_EV, int eigenv, bool extrap=false) {
    return getTRFweightWithPermRW(m_calibName, nbtag, isIncl, pdgid_EV, eigenv, extrap);
  };

  // Extrapolation uncertainty
  double getTRFextrapUncertainty(std::string calib, unsigned int nbtag, bool isIncl, bool isUp, unsigned int pdgid_EV=999); // latest argument in case of decorrelation, not the current recommendation
  double getTRFextrapUncertainty(unsigned int nbtag, bool isIncl, bool isUp, unsigned int pdgid_EV=999) {
    return getTRFextrapUncertainty(m_calibName, nbtag, isIncl, isUp, pdgid_EV);
  };
  void getTRFextrapUncertainties(std::string calib, unsigned int limit, std::vector<double> &trf_weight_ex, std::vector<double> &trf_weight_in, bool isUp, unsigned int pdgid_EV=999);
  void getTRFextrapUncertainties(unsigned int limit, std::vector<double> &trf_weight_ex, std::vector<double> &trf_weight_in, bool isUp, unsigned int pdgid_EV=999) {
    return getTRFextrapUncertainties(m_calibName, limit, trf_weight_ex, trf_weight_in, isUp, pdgid_EV);
  };

  // Choose permutation
  void chooseTagPermutation(std::string calib, unsigned int nbtag, std::vector<std::vector<bool> > &trf_chosen_perm_ex, std::vector<std::vector<bool> > &trf_chosen_in);
  std::vector<bool> chooseTagPermutation(std::string calib, unsigned int nbtag, bool isIncl=false);
  void chooseTagPermutation(unsigned int nbtag, std::vector<std::vector<bool> > &trf_chosen_perm_ex, std::vector<std::vector<bool> > &trf_chosen_in) {
    return chooseTagPermutation(m_calibName, nbtag, trf_chosen_perm_ex, trf_chosen_in);
  };
  std::vector<bool> chooseTagPermutation(unsigned int nbtag, bool isIncl=false) {
    return chooseTagPermutation(m_calibName, nbtag, isIncl);
  };

  // set permutation if using a permutation previously chosen
  void setAllPermutations(std::string calib, std::vector<std::vector<bool> > &tagconf_ex, std::vector<std::vector<bool> > &tagconf_in);
  void setPermutation(std::string calib, std::vector<bool> &tagconf, bool isIncl, unsigned int nbtag);

  // get permutation proba comp to nominal
  double getPermutationRW(std::string calib, bool isIncl, unsigned int nbtag=99, std::string ncalib="", unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false);
  double getPermutationRW(bool isIncl, unsigned int nbtag=99, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false) {
    return getPermutationRW(m_calibName, isIncl, nbtag, m_calibName, pdgid_EV, eigenv, extrap);
  };
  double getPermutationRW(std::string calib, bool isIncl, unsigned int nbtag=99, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false) {
    return getPermutationRW(calib, isIncl, nbtag, calib, pdgid_EV, eigenv, extrap);
  };
  // for nominal RW between 2 calibs
  double getPermutationRW(std::string calib, bool isIncl, int nbtag, std::string ncalib) {
    return getPermutationRW(calib, isIncl, nbtag, ncalib, 999, 0, false);
  };

  // only for nominal, already coded for systematics, supposing all permutations set already (else warning)
  void getAllPermutationsRW(std::string calib, std::vector<double> &prw_ex, std::vector<double> &prw_in);

  // Choose tag bins (depends on calibration)
  void chooseTagBins(std::string calib, std::vector<std::vector<int> > &trf_bin_ex, std::vector<std::vector<int> > &trf_bin_in);
  std::vector<int> chooseTagBins(std::string calib, std::vector<bool> &tagconf, bool isIncl, unsigned int nbtag);
  void chooseTagBins(std::vector<std::vector<int> > &trf_bin_ex, std::vector<std::vector<int> > &trf_bin_in) {
    return chooseTagBins(m_calibName, trf_bin_ex, trf_bin_in);
  };
  std::vector<int> chooseTagBins(std::vector<bool> &tagconf, bool isIncl, unsigned int nbtag) {
    return chooseTagBins(m_calibName, tagconf, isIncl, nbtag);
  };

  // set tag bins configuration if previously chosen
  // attention: could have bin saved in double -> unit of the tagger or in int -> bin number
  void setTagBins(std::string calib, std::vector<double> &tagws, bool isIncl, unsigned int nbtag, bool cumToCont=false);
  void setTagBins(std::string calib, std::vector<int> &tagbins, bool isIncl, unsigned int nbtag, bool cumToCont=false);
  void setAllTagBins(std::string calib, std::vector<std::vector<int> > &trf_bin_ex, std::vector<std::vector<int> > &trf_bin_in, bool cumToCont=false);
  void setAllTagBins(std::string calib, std::vector<std::vector<double> > &trftagw_ex, std::vector<std::vector<double> > &trf_bin_in, bool cumToCont=false);

  std::vector<int> getTagBins(std::string calib, bool isIncl, unsigned int nbtag);
  std::vector<double> getTagBinsD(std::string calib, bool isIncl, unsigned int nbtag);
  void getAllTagBins(std::string calib, std::vector<std::vector<int> > &trf_bin_ex, std::vector<std::vector<int> > &trf_bin_in);
  void getAllTagBins(std::string calib, std::vector<std::vector<double> > &trf_bin_ex, std::vector<std::vector<double> > &trf_bin_in);

  double getTagBinsRW(std::string calib, bool isIncl, unsigned int nbtag, std::string ncalib, unsigned int pdgid_EV, int eigenv, bool extrap=false);
  double getTagBinsRW(bool isIncl, unsigned int nbtag, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false) {
    return getTagBinsRW(m_calibName, isIncl, nbtag, m_calibName, pdgid_EV, eigenv, extrap);
  };
  double getTagBinsRW(std::string calib, bool isIncl, unsigned int nbtag, unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false) {
    return getTagBinsRW(calib, isIncl, nbtag, calib, pdgid_EV, eigenv, extrap);
  };
  // for nominal RW between 2 calibs
  double getTagBinsRW(std::string calib, bool isIncl, unsigned int nbtag, std::string ncalib) {
    return getTagBinsRW(calib, isIncl, nbtag, ncalib, 999, 0, false);
  };

  // only for nominal, already coded for systematics, supposing all permutations set already (else warning)
  void getAllTagBinsRW(std::string calib, std::vector<double> &tbrw_ex, std::vector<double> &tbrw_in);

  // convert tag bins in "bin" unit in tagger unit (typically doubles between 0 and 1) and contrary
  std::vector<double> getTagWfromTagBins(std::string calib,std::vector<int> &tagbins);
  std::vector<int> getTagBinsfromTagW(std::string calib,std::vector<double> &tagws);

  // get number of EV variations -> from in the true flavour of the jets (B=5, C=4, Light=0, tau -> use the C ones for the moment)
  unsigned int getNumEV(unsigned int pdgid_EV, std::string calib);
  unsigned int getNumEV(unsigned int pdgid_EV) {
    return getNumEV(pdgid_EV, m_calibName);
  };

private:
  void initializeCalibrations(std::string confFile);
  std::string getCalibOPflag(std::string calname, std::string jetcol, std::string tagalgo);

  struct BtagCalib {
    std::string name;
    std::string confFile;
    std::string tagAlgo;
    std::string jetColSF;
    std::string jetColEff;
    std::string exceptSF;
    bool useSF;
    unsigned int nmaps;
    bool inverseJetCol; // EM or LC, default = LC
    bool inverseJetColEff; // EM or LC, default = LC
    bool isCont;
    bool isContTRF;
    std::string jetCalAlg;
    std::string jetCalAlgInv;
    unsigned int OPbin;
    std::map<unsigned int,std::map<unsigned int, unsigned int> > iSF;
    std::map<unsigned int,std::map<unsigned int, std::vector<unsigned int> > > iEff;
    std::map<unsigned int, unsigned int> nEV;
    std::map<unsigned int, unsigned int> extrapUnc;
  };

  unsigned int m_debug;

  TRandom3 m_rand;

  double m_OP;
  std::string m_jetCol; // (the real one)

  // boolean for systematic uncertainties reweighting
  bool m_rwSystForPerm;
  bool m_rwSystForTagBins;

  bool m_testMode; // set SF to 1, only test efficiencies
  bool m_useExtrapApproxErr; // set SF to 1, only test efficiencies

  // To check TRF closure -> mainly when implementing a new calibration
  bool m_checkClosure;

  std::string m_calibName; // if more than one calibs, store the reference one if set
  std::map<std::string, BtagCalib> m_calibMap;
  std::map<std::string, Analysis::CalibrationDataInterfaceROOT*> m_cdiTools;
  
  // std::map<int, std::string> m_pdgFlav = {{5,"B"}, {4,"C"}, {15,"T"}, {0,"Light"}};
  static std::map<int, std::string> m_pdgFlav;
  static std::map<int, std::string> setPdgFlav();

  std::vector<double> m_pt, m_eta, m_tagw;
  std::vector<int> m_pdg;
  std::vector<unsigned int> m_imap;

  // objects characteristics of a calibration / systematic -> only save nominal syst not needed in mem here
  // -> stored in a structure, then map of calibs
  struct TRFres {
    std::map<int,std::map<int,double> > eff;
    std::map<int,std::map<int,double> > SF;
    std::vector<double> trfw_ex;
    std::vector<double> trfw_in;
    std::vector<std::vector<bool> > perm_ex;
    std::vector<std::vector<bool> > perm_in;
    std::vector<double> permprob_ex;
    std::vector<double> permprob_in;
    std::vector<double> rwpcals_ex;
    std::vector<double> rwpcals_in;
    std::vector<std::vector<int> > tbins_ex;
    std::vector<std::vector<int> > tbins_in;
    std::vector<double> binsprob_ex;
    std::vector<double> binsprob_in;
    std::vector<double> rwtbcals_ex;
    std::vector<double> rwtbcals_in;
    std::map<int,std::vector<double> > trfwsys_ex;
    std::map<int,std::vector<double> > trfwsys_in;
  };
  
  std::map<std::string, TRFres> m_trfRes;

  // Systematics...
  int getSystId(unsigned int pdgid_EV=999, int eigenv=0, bool extrap=false);

  // Tag rate function
  // Permutations: njets, ntags, permutations
  std::map<int, std::vector<std::vector<std::vector<bool> > > > m_perms;
  std::vector<std::vector<double> > m_permsWeight; // First vector = N b-tags required, second vector = vector of permutation -> 1 trf weight per permutation
  std::vector<std::vector<double> > m_permsSumWeight; // First vector = N b-tags required, second vector = vector of permutation -> 1 trf sum weight per permutation
  std::vector<std::vector<bool> > generatePermutations(int njets, int tags, int start=0);

  // maps for SF and efficiencies to make code quicker
  // map of efficiencies: jet index, tag bin, efficiency
  std::map<int,std::map<int,double> > m_eff;
  double getEff(double pt, double eta, int pdgid, unsigned int iop, std::string calib="", unsigned int imap=0);
  void getAllEff(std::string calib);
  // map of SF: jet index, tag bin, SF
  std::map<int,std::map<int,double> > m_SF;
  double getSF(double pt, double eta, int pdgid, unsigned int iop, std::string calib="", unsigned int imap=0, int ev=0, bool extrap=false);
  void getAllSF(std::string calib, unsigned int pdg_ev=999, int ev=0, bool extrap=false);
  double getExtrapApproxErr(double pt, double eta, int pdgid);
  // Only for cumulative direct tagging !!!
  double getIneffSF(double pt, double eta, int pdgid, unsigned int iop, std::string calib="", unsigned int imap=0, int ev=0, bool extrap=false);

  // TRF weight
  double trfWeight(const std::vector<bool> &tags, std::string calib);
  std::vector<double> m_trf_weight_ex, m_trf_weight_in;

  // Permutation choice
  std::vector<std::vector<bool> > m_trf_chosen_perm_ex, m_trf_chosen_perm_in;

  // Tag bin choice
  std::vector<std::vector<int> > m_trf_chosen_bins_ex, m_trf_chosen_bins_in;
  std::vector<int> chooseTagBins_cum(std::string calib, std::vector<bool> &tagconf, bool isIncl, unsigned int nbtag);
  std::vector<int> chooseTagBins_cont(std::string calib, std::vector<bool> &tagconf, bool isIncl, unsigned int nbtag);

  void setAdditionalTagBin(std::string calib, std::vector<int> &tagbins);

  double getTagBinsConfProb(std::string calib, std::vector<int> &tagws, bool cumToCont=false);

  // debug functions
  void printPermutations();
};

#endif
