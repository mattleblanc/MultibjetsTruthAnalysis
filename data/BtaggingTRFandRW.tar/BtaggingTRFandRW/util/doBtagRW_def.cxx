#include <iostream>
#include "BtaggingTRFandRW/BtagOP.h"
#include "BtaggingTRFandRW/TRFinterface.h"

#include <TFile.h>
#include <TTree.h>
#include <TSystem.h>
#include <TString.h>
#include <TLorentzVector.h>

#include <vector>
#include <map>

using namespace std;

vector<int> matchJetsAndPartjets(const vector<TVector3> &jets, const vector<TVector3> &pjets, const vector<unsigned int> &indpj, vector<int> &matchind)
{
  // vector<int> matchind(jets.size(),-1);
  vector<int> matchrind(jets.size(),-1);
  for(unsigned int ij=0; ij<jets.size(); ij++) {
    for(unsigned int ipj=0; ipj<pjets.size(); ipj++) {
      if(jets.at(ij).DeltaR(pjets.at(ipj)) <= 0.3) {
	if(matchind.at(ij) != -1) {
	  if(jets.at(ij).DeltaR(pjets.at(ipj)) > jets.at(ij).DeltaR(pjets.at(matchind.at(ij)))) continue;
	  matchind.at(ij) = ipj;
	  matchrind.at(ij) = indpj.at(ipj);
	} else {
	  matchind.at(ij) = ipj;
	  matchrind.at(ij) = indpj.at(ipj);
	}
      }
    }
    // cout << "matched to jet " << ij << "  rind = " << matchrind.at(ij) << endl;
  }
  return matchrind;
}

void loopOnTree(TTree *tree, TRFinterface cbc, bool isCont, string inFile, string odir, int first, int last, bool isttbar, TFile *ofich)
{
  string cal = "CumDef", cal2 = "ContDef";
  if(isCont) cal = "ContDef", cal2 = "CumDef";

  double trfw=0, trfw2=0;
  vector<double> *trf_ex=0, *trf_in=0;

  vector<double> *jpt=0, *jeta=0, *jtagw=0, *jphi=0, *jE=0;
  vector<int> *jpdg=0;
  vector<double> *TRFweight_in=0, *TRFweight_ex=0;
  vector<vector<bool> > *TRFChosenTag_in=0, *TRFChosenTag_ex=0;
  vector<vector<double> > *TRFTagW_in=0, *TRFTagW_ex=0;
  float btagSF=0.;
  int HFtype = 0, nbLepVetoed = 0;
  float MCweightXS = 0., LeptonSF = 0., ttbarTopPtDataWeight = 0., ttbb_default_rw = 0.;

  vector<double> *pjpt=0, *pjeta=0, *pjphi=0;
  vector<int> *pjpdg=0, *pjid=0, *pjcount=0;

  // vector<vector<double> > *trfsys_ex=0, *trfsys_in=0;
  vector<vector<double> > trfsys_ex, trfsys_in;
  // std::vector<std::vector<int> > *ptrfsys_ex=NULL, *ptrfsys_in=NULL;
  // trfsys_ex->clear(); 
  // cout << "size du vec = " << ptrfsys_ex->size() << endl;
  cout << "size du vec = " << trfsys_ex.size() << endl;
  unsigned int eventNum = 0;
  tree->SetBranchStatus("*",0);
  tree->SetBranchStatus("EventNumber",1);
  tree->SetBranchStatus("jet_*",1);
  tree->SetBranchStatus("TRFMCweight_*",1);
  tree->SetBranchStatus("TRFChosenTag_*",1);
  tree->SetBranchStatus("TRFDiscreteBTagWeight_*",1);
  tree->SetBranchStatus("BtagWeight",1);
  tree->SetBranchStatus("HFtype",1);
  tree->SetBranchStatus("nbLepVetoed",1);
  tree->SetBranchStatus("MCweightXS",1);
  tree->SetBranchStatus("LeptonSF",1);
  tree->SetBranchStatus("ttbarTopPtDataWeight",1);
  tree->SetBranchStatus("ttbb_default_rw",1);
  tree->SetBranchStatus("particle_*",1);
  
  // tree->SetBranchAddress("jet_pt",&jpt);
  tree->SetBranchAddress("jet_pt",&jpt);
  tree->SetBranchAddress("jet_eta",&jeta);
  tree->SetBranchAddress("jet_btag_weight",&jtagw);
  // tree->SetBranchAddress("jet_MV1",&jtagw);
  tree->SetBranchAddress("jet_trueflav",&jpdg);
  tree->SetBranchAddress("jet_phi",&jphi);
  tree->SetBranchAddress("jet_E",&jE);
  tree->SetBranchAddress("EventNumber",&eventNum);
  tree->SetBranchAddress("TRFMCweight_ex",&TRFweight_ex);
  tree->SetBranchAddress("TRFMCweight_in",&TRFweight_in);
  tree->SetBranchAddress("TRFChosenTag_ex",&TRFChosenTag_ex);
  tree->SetBranchAddress("TRFChosenTag_in",&TRFChosenTag_in);
  tree->SetBranchAddress("TRFDiscreteBTagWeight_ex",&TRFTagW_ex);
  tree->SetBranchAddress("TRFDiscreteBTagWeight_in",&TRFTagW_in);
  tree->SetBranchAddress("BtagWeight",&btagSF);
  tree->SetBranchAddress("HFtype",&HFtype);
  tree->SetBranchAddress("nbLepVetoed",&nbLepVetoed);
  tree->SetBranchAddress("MCweightXS",&MCweightXS);
  tree->SetBranchAddress("LeptonSF",&LeptonSF);
  tree->SetBranchAddress("ttbarTopPtDataWeight",&ttbarTopPtDataWeight);
  tree->SetBranchAddress("ttbb_default_rw",&ttbb_default_rw);
  tree->SetBranchAddress("jet_AntiKt4Truth_pt",&pjpt);
  tree->SetBranchAddress("jet_AntiKt4Truth_eta",&pjeta);
  tree->SetBranchAddress("jet_AntiKt4Truth_phi",&pjphi);
  tree->SetBranchAddress("particle_jet_trueflav",&pjpdg);
  tree->SetBranchAddress("particle_jet_id",&pjid);
  tree->SetBranchAddress("particle_jet_count",&pjcount);
  cout << "aall branches done" << endl;
  string cbccase = "cumCalc";
  if(isCont) cbccase = "contCalc";
  TTree *otree = new TTree(("otree"+inFile+"_"+cbccase).c_str(),("otree"+inFile+"_"+cbccase).c_str());
  otree->Branch("trfw",&trfw);
  otree->Branch("trfw2",&trfw2);
  otree->Branch("trf_ex",&trf_ex);
  otree->Branch("trf_in",&trf_in);

  // TH1F *h_nbjets = new TH1F("h_nbjets","nbjets;# b-jets",7,0,7);
  TH1F *h_mv1_1 = new TH1F(("h_mv1_1"+inFile+"_"+cbccase).c_str(),"mv1_1;MV1 jet_{1}",5,0,5);
  TH1F *h_mv1_1_noRW = new TH1F(("h_mv1_1_noRW"+inFile+"_"+cbccase).c_str(),"mv1_1_noRW;MV1 jet_{1} (no perm and tagb rw)",5,0,5);
  TH1F *h_mv1_1_notbRW = new TH1F(("h_mv1_1_notbRW"+inFile+"_"+cbccase).c_str(),"mv1_1_noRW;MV1 jet_{1} (no tagb rw)",5,0,5);
  TH1F *h_mv1_1_in = new TH1F(("h_mv1_1_in"+inFile+"_"+cbccase).c_str(),"mv1_1_in;MV1 jet_{1} (initial)",5,0,5);

  // plots for ttbb, ttcc and ttl
  // plots of Nj, Mbtag
  // distributions: pt, eta, HT

  unsigned int nbhist = 0;

  vector<TString> samp;
  if(isttbar) samp.push_back("ttbb"), samp.push_back("ttcc"), samp.push_back("ttl");
  else samp.push_back("samp");
  vector<TString> cals;
  // if(inFile.find("cum") != string::npos) cals = {"CumDT","ContDT","CumTRF","ContDefTRF_rw"};
  // if(inFile.find("cum") != string::npos) cals = {"CumDT","ContDefTRF_rw"};// ,"ContLCTRF_rw","ContAe12ptTRF_rw","ContFae12ptTRF_rw"};
  // if(inFile.find("cum") != string::npos) cals = {"ContAe4jTRF_rw","ContAe10ptL1LTRF_rw","ContFae12ptTRF_rw","ContDefTRF_rw"};
  // if(inFile.find("cum") != string::npos) cals = {"CumDT","Cont17ae14ptTRF_rw","Cont17ae14pt_ttlTRF_rw"};
  if(inFile.find("cum") != string::npos) {
    cals.push_back("CumLC_ttH_ljetsDT"), cals.push_back("CumLC_ttH_ljetsTRF");
  }
  // if(inFile.find("cum") != string::npos) {
  //   cals.push_back("CumDT") ,cals.push_back("CumTRF");
  //   cals.push_back("CumNewLCDT"), cals.push_back("CumNewLCTRF");
  //   cals.push_back("CumNewLCP8DT"), cals.push_back("CumNewLCP8TRF");
  // }
  // if(inFile.find("cum") != string::npos) cals = {"ContDefDT","Cont17ae14ptAlTRF_rw"};
  // if(inFile.find("cum") != string::npos) cals = {"CumDT","ContDefDT","ContEMDT","CumTRF","ContDefTRF_rw","ContEMTRF_rw"};
  // if(inFile.find("cum") != string::npos) cals = {"ContAe12ptLTRF_rw","ContAe12ptTRF_rw"};
  else cals.push_back("ContTRF");
  // map<TString, vector<vector<TH1F*> > > mapHist;
  map<TString, map<TString,vector<vector<TH1F*> > > > mapHist;
  for(unsigned int is=0; is<samp.size(); is++) {
    map<TString, vector<vector<TH1F*> > > tmap;
    for(unsigned int ical=0; ical<cals.size(); ical++) {
      vector<vector<TH1F*> > histVec;
      for(unsigned int nj=4; nj < 7; nj++) {
      // for(unsigned int nj=1; nj < 5; nj++) {
	for(unsigned int nb=0; nb < 5; nb++) {
	// for(unsigned int nb=0; nb < nj+1; nb++) {
	  vector<TH1F*> tmpVec;
	  TString sampl = "";
	  if(samp.at(is) != "samp") sampl = "_"+samp.at(is);
	  // TString channel = Form("%dj%db_",nj,nb)+inFile;
	  TString channel = Form("%dj%db_",nj,nb)+cals.at(ical)+"_"+inFile+sampl;
	  tmpVec.push_back(new TH1F("HT_"+channel,"HT_"+channel+";H_{T}[GeV]",50,0,1000));
	  // cout << "channel = " << channel << endl;
	  for(unsigned int mj=1; mj<5; mj++) {
	    float upPt = 500.;
	    if(mj >= 3) upPt = 250.;
	    // tmpVec.push_back(new TH1F("jet"+TString(mj)+"_pt_"+channel,"jet"+TString(mj)+"_pt_"+channel+";p_{T}^{jet "+TString(mj)+"}[GeV]",100,0,1000));
	    // tmpVec.push_back(new TH1F("jet"+TString(mj)+"_eta_"+channel,"jet"+TString(mj)+"_eta_"+channel+";#eta^{jet "+TString(mj)+"}",20,-2.5,2.5));
	    tmpVec.push_back(new TH1F(Form("jet%d_pt_%s",mj,channel.Data()),Form("jet%d_pt_%s;p_{T}^{jet %d}[GeV]",mj,channel.Data(),mj),50,0.,upPt));
	    tmpVec.push_back(new TH1F(Form("jet%d_eta_%s",mj,channel.Data()),Form("jet%d_eta_%s;#eta^{jet %d}",mj,channel.Data(),mj),20,-2.5,2.5));
	    tmpVec.push_back(new TH1F(Form("jet%d_phi_%s",mj,channel.Data()),Form("jet%d_phi_%s;#phi^{jet %d}",mj,channel.Data(),mj),20,-3.2,3.2));
	    tmpVec.push_back(new TH1F(Form("jet%d_mv1_%s",mj,channel.Data()),Form("jet%d_mv1_%s;MV1^{jet %d}",mj,channel.Data(),mj),5,0,5));
	  }
	  tmpVec.push_back(new TH1F("trueFlavs_"+channel,"trueFlav_"+channel+";100#timesNb + 10#timesNc + Nl",550,0.,550.));
	  tmpVec.push_back(new TH1F("trueFlavsTj_"+channel,"trueFlavTj_"+channel+";100#timesNb + 10#timesNc + Nl",550,0.,550.));
	  tmpVec.push_back(new TH1F("HTfw_"+channel,"HTfw_"+channel+";H_{T}[GeV]",50,0,1000));
	  for(unsigned int ih=0; ih<tmpVec.size(); ih++) tmpVec.at(ih)->Sumw2();
	  histVec.push_back(tmpVec);
	  nbhist = tmpVec.size();
	}
      }
      //  tmap[cals.at(ical)] = histVec;
      cout << "samp = " << samp.at(is) << "  cal = " << cals.at(ical) << endl;
      mapHist[samp.at(is)][cals.at(ical)] = histVec;
    }
    // mapHist[samp.at(is)][cals.at(ical)] = 
  }


  if(last == -1) last = tree->GetEntries();
  if(last > tree->GetEntries()) last = tree->GetEntries();
  for(Long_t i=first; i<last; i++) {
    tree->GetEntry(i);
    // cout << "leading pt = " << jpt->at(0) << "  eta = " << jeta->at(0) << "  jpdg = " << jpdg->at(0) << "  tagw = " << jtagw->at(0) << endl;

    // if(!isttbar && 
    if(nbLepVetoed != 0) continue;
    float weight = MCweightXS*LeptonSF*20276.9*ttbarTopPtDataWeight*ttbb_default_rw;

    vector<double> qpt = *jpt, qeta = *jeta, qtagw = *jtagw, qE = *jE, qphi = *jphi;
    vector<int> qpdg = *jpdg;
    unsigned int njets = (jpt->size() > 6) ? 6 : jpt->size();
    // unsigned int nbjets = 0, nBbjets = 0;
    // qpt.clear(), qeta.clear(), qtagw.clear(), qpdg.clear();
    // for(unsigned int j=0; j<jtagw->size(); j++) {
    //   if(abs(jpdg->at(j)) == 5) {
    // 	// if(abs(jpdg->at(j)) == 0) {
    // 	nbjets++;
    // 	if(jtagw->at(j) > 0.7892) nBbjets++;
    // 	// if(jpt->at(j) > 300000) qpt.push_back(280000);
    // 	// else 
    // 	qpt.push_back(jpt->at(j));
    // 	qeta.push_back(jeta->at(j));
    // 	qtagw.push_back(jtagw->at(j));
    // 	qpdg.push_back(jpdg->at(j));
    //   }
    // }
    // cout << "size qpt = " << qpt.size() << endl;
    // njets = (nbjets > 4) ? 4 : nbjets;
    // njets = (qpt.size() > 4) ? 4 : qpt.size();
    njets = (qpt.size() > 6) ? 6 : qpt.size();
    // if(njets == 0) continue;

    // cbc.setJets(*jpt, *jeta, *jpdg, *jtagw);
    // cbc.setJets(qpt, qeta, qpdg, qtagw);

    vector<TVector3> tv3jets, tv3pjets;
    vector<unsigned int> indpj;
    TVector3 tmp;
    // matching particle jets
    for(unsigned int ij=0; ij<jpt->size(); ij++) {
      tmp.SetPtEtaPhi(jpt->at(ij),jeta->at(ij),jphi->at(ij));
      tv3jets.push_back(tmp);
    }
    unsigned int nb=0, nc=0;
    for(unsigned int ipj=0; ipj<pjpt->size(); ipj++) {
      if(pjpt->at(ipj) < 15000) continue;
      if(fabs(pjeta->at(ipj)) > 2.5) continue;
      tmp.SetPtEtaPhi(pjpt->at(ipj),pjeta->at(ipj),pjphi->at(ipj));
      indpj.push_back(ipj);
      tv3pjets.push_back(tmp);
      if(abs(pjpdg->at(ipj)) == 5 && pjid->at(ipj) < 3) nb++;
      else if(abs(pjpdg->at(ipj)) == 4 && pjid->at(ipj) > -3) nc++;
    }

    // new classification
    if(nb > 0) HFtype = 500;
    else if(nc > 0) HFtype = -500;

    // cout << "nbre de jets = " << jpt->size() << "   in tv3 = " << tv3jets.size() << "  part jets = " << pjpt->size() << "  in tv3 = " << tv3pjets.size() << "  pour int = " << indpj.size() << endl;
    vector<int> matchind(jpt->size(),-1);
    vector<int> matchrind = matchJetsAndPartjets(tv3jets, tv3pjets, indpj, matchind);
    vector<unsigned int> matchid(jpt->size(),0);
    vector<int> matchpdg(jpt->size(),0), matchqual(jpt->size(),0);
    // also look for double matches
    for(unsigned int ij=0; ij<matchind.size(); ij++) {
      if(matchind.at(ij) != -1) {
	for(unsigned int ik=ij+1; ik<matchind.size(); ik++) {
	  if(matchind.at(ik) == matchind.at(ij)) {
	    if(abs(qpdg.at(ij)) > 3 && abs(qpdg.at(ik)) > 3) { // only in heavy flavour cases, light ones won't be degraded and same maps for top/W and others
	      if(pjcount->at(matchrind.at(ij)) > 1) continue;  // 2 heavy quarks at beginning possible to get 2 HF jets...
	      if(tv3jets.at(ij).DeltaR(tv3pjets.at(matchind.at(ij))) < tv3jets.at(ik).DeltaR(tv3pjets.at(matchind.at(ik)))) { // ij will be matched
		if(pjpdg->at(matchrind.at(ij)) == jpdg->at(ij)) matchqual.at(ij) = 3;
		if(pjpdg->at(matchrind.at(ik)) == jpdg->at(ik)) matchqual.at(ik) = -3;
		else matchqual.at(ik) = -1;
	      } else { // ik will be matched
		if(pjpdg->at(matchrind.at(ik)) == jpdg->at(ik)) matchqual.at(ik) = 3;
		if(pjpdg->at(matchrind.at(ij)) == jpdg->at(ij)) matchqual.at(ij) = -3;
		else matchqual.at(ij) = -1;
	      }
	    }
	  } 
	} // end of loop over other jets to remove ovelaps with same particle jets (if count == 1)
	if(abs(qpdg.at(ij)) == 15) continue;
	if(matchqual.at(ij) > 0 && pjpdg->at(matchrind.at(ij)) == jpdg->at(ij)) matchqual.at(ij) = 3;
	// test of degrading HF reco HF matched to light part jet (too low pt meson)
	if(abs(qpdg.at(ij)) > 3 && abs(pjpdg->at(matchrind.at(ij))) == 0) qpdg.at(ij) = 0;
	if(abs(pjid->at(matchrind.at(ij))) < 1) matchid.at(ij) = 2;
	else if(abs(pjid->at(matchrind.at(ij))) == 1 || abs(pjid->at(matchrind.at(ij))) == 2) matchid.at(ij) = 3;
	else {
	  if(matchqual.at(ij) < 0) {
	    matchid.at(ij) = 2;	    
	    qpdg.at(ij) = 0;
	  } else {
	    if(abs(pjpdg->at(matchind.at(ij))) == 5 && pjid->at(matchind.at(ij)) < 3) matchid.at(ij) = 2; // others for b
	    else if(abs(pjpdg->at(matchind.at(ij))) == 4 && pjid->at(matchind.at(ij)) > -3) matchid.at(ij) = 2;
	    else matchid.at(ij) = 1; // no problem for lights, same maps (as soon as not 0)
	  }
	  matchpdg.at(ij) = pjpdg->at(matchind.at(ij));
	}
      } else { // not matched jets
	if(abs(qpdg.at(ij)) == 15) matchid.at(ij) = 0;
	else if(abs(qpdg.at(ij)) == 0) matchid.at(ij) = 2;
	else matchid.at(ij) = 2; // def=2  now eff = 0 // take others for not matched jets (for the moment)
      }
    }

    cbc.setJets(qpt, qeta, qpdg, qtagw, matchid);


    // for(unsigned int q=0; q<qpt.size(); q++) cout << "pt = " << qpt.at(q) << "  eta = " << qeta.at(q) << "  jpdg = " << qpdg.at(q) << "  tagw = " << qtagw.at(q) << endl;
    // cout << "leading pt = " << qpt.at(0) << "  eta = " << qeta.at(0) << "  jpdg = " << qpdg.at(0) << "  tagw = " << qtagw.at(0) << endl;
    double HT = 0.;
    for(unsigned int j=0; j<qpt.size(); j++) HT += qpt.at(j);

    unsigned int nBjets = 0;
    for(unsigned int j=0; j<qtagw.size(); j++) 
      if(qtagw.at(j) > 0.7892) nBjets++;
    // unsigned int savedNBjets = nBjets;
    nBjets = (nBjets > 4) ? 4 : nBjets;
    // nBjets = (nBbjets > 4) ? 4 : nBbjets;

    unsigned int nbjets = 0, ncjets = 0, nljets = 0, ntjets = 0;
    bool highptbjet = false, highptljet = false, highptcjet = false;
    for(unsigned int ij = 0; ij < qpdg.size(); ij++) {
      if(abs(qpdg.at(ij)) == 5) {
        nbjets++;
	if(jpt->at(ij)>400000) highptbjet = true;
      } else if(abs(qpdg.at(ij)) == 4) {
        ncjets++;
        if(jpt->at(ij)>400000) highptcjet = true;
      } else if(abs(qpdg.at(ij)) == 0) {
	nljets++;
        if(jpt->at(ij)>750000) highptljet = true;
      } else if(abs(qpdg.at(ij)) == 15) ntjets++;

      // if(abs(qpdg.at(ij)) == 5) nbjets++;
      // else if(abs(qpdg.at(ij)) == 4) ncjets++;
      // else if(abs(qpdg.at(ij)) == 0) nljets++;
      // else if(abs(qpdg.at(ij)) == 15) ntjets++;
    }

    int Ntjets = 100*nbjets+10*ncjets+nljets;
    if(Ntjets > 549) Ntjets = 549;
    
    TString sampl = "samp";
    if(isttbar) {
      if(HFtype == 0) sampl = "ttl";
      else if(HFtype > 0) sampl = "ttbb";
      else if(HFtype < 0) sampl = "ttcc";
    }

    // vector<double> trfw_ex = *TRFweight_ex, trfw_in = *TRFweight_in;
    // vector<vector<bool> > perm_ex = *TRFChosenTag_ex, perm_in = *TRFChosenTag_in;
    // vector<vector<double> > tbins_ex = *TRFTagW_ex, tbins_in = *TRFTagW_in;
    vector<double> trfw_ex, trfw_in;
    vector<vector<bool> > perm_ex, perm_in;
    vector<vector<int> > tbins_ex, tbins_in;

    if(inFile.find("cum") != string::npos) {
      cbc.setSeed(eventNum+jpt->size());
      // if(qpt.size() == jpt->size()) {
      // 	// cbc.setTRFweights("CumDef",*TRFweight_ex,*TRFweight_in);
      // 	// cbc.setAllPermutations("CumDef",*TRFChosenTag_ex,*TRFChosenTag_in);
      // 	// cbc.setAllTagBins("CumDef",*TRFTagW_ex, *TRFTagW_in);
      // cbc.setTRFweights("CumDef",trfw_ex,trfw_in);
      // cbc.getTRFweights("CumDef",7,trfw_ex,trfw_in);
      // cbc.setAllPermutations("CumDef",perm_ex,perm_in);
      // cbc.setAllTagBins("CumDef",tbins_ex, tbins_in);
      // } else {
      cbc.getTRFweights("CumDef",4,trfw_ex,trfw_in);
      perm_ex.clear(), perm_in.clear();
      cbc.chooseTagPermutation("CumDef",4,perm_ex,perm_in);
      cbc.chooseTagBins("CumDef",tbins_ex, tbins_in);
      // cout << "nom (CumDef) = " << trfw_in.at(2) << endl;
      // for(unsigned int iev=1; iev < cbc.getNumEV(5,"CumDef")+1; iev++) {
      // 	cout << "B: iev = " << iev << "  SFup = " << cbc.getTRFweightWithPermRW("CumDef",2, true, 5,iev,false) << "  SFdown = " << cbc.getTRFweightWithPermRW("CumDef",2,true,5,-iev,false) << endl;
      // }
      // for(unsigned int iev=1; iev < cbc.getNumEV(4,"CumDef")+1; iev++) {
      // 	cout << "C: iev = " << iev << "  SFup = " << cbc.getTRFweightWithPermRW("CumDef",2, true, 4,iev,false) << "  SFdown = " << cbc.getTRFweightWithPermRW("CumDef",2,true,4,-iev,false) << endl;
      // }
      // for(unsigned int iev=1; iev < cbc.getNumEV(0,"CumDef")+1; iev++) {
      // 	cout << "L: iev = " << iev << "  SFup = " << cbc.getTRFweightWithPermRW("CumDef",2, true, 0,iev,false) << "  SFdown = " << cbc.getTRFweightWithPermRW("CumDef",2,true,0,-iev,false) << endl;
      // }

      for(unsigned int ical=0; ical<cals.size(); ical++) {

	if(cals.at(ical).Contains("DT")) {
	  // cout << "DT" << endl;
	  // if test mode
	  // btagSF = 1.;
	  double btagSF_orig = btagSF;
	  TString calib = cals.at(ical);
	  if(cals.at(ical).Contains("Cont")) {
	    calib.ReplaceAll("DT","");
	  } else {
	    if(cals.at(ical) == "CumDT") calib = "CumDef";
	    else calib.ReplaceAll("DT","");
	  }
	  btagSF = cbc.getEvtSF(string(calib));
	  // cout << "Event = " << eventNum << "  btagSF(nom) = " << btagSF << endl;
	  //           for(unsigned int iev=1; iev < cbc.getNumEV(5,string(calib))+1; iev++) {
	  //             cout << "B: iev = " << iev << "  SFup = " << cbc.getEvtSF(string(calib),5,iev,false) << "  SFdown = " << cbc.getEvtSF(string(calib),5,-iev,false) << endl;
	  //           }
	  //           for(unsigned int iev=1; iev < cbc.getNumEV(4,string(calib))+1; iev++) {
	  //             cout << "C: iev = " << iev << "  SFup = " << cbc.getEvtSF(string(calib),4,iev,false) << "  SFdown = " << cbc.getEvtSF(string(calib),4,-iev,false) << endl;
	  //           }
	  //           for(unsigned int iev=1; iev < cbc.getNumEV(0,string(calib))+1; iev++) {
	  //             cout << "L: iev = " << iev << "  SFup = " << cbc.getEvtSF(string(calib),0,iev,false) << "  SFdown = " << cbc.getEvtSF(string(calib),0,-iev,false) << endl;
	  //           }
	  //           if(highptbjet || highptcjet || highptljet) cout << "nom = " << btagSF << "  extrap up = " << cbc.getEvtSF(string(calib),999,1,true) 
	  //                  << "  down = " << cbc.getEvtSF(string(calib),999,-1,true) << endl;

	  if(calib == "CumDef" && btagSF != btagSF_orig) cout << "Issue btagSF different from default calculation, orig = " << btagSF_orig << "  mine = " << btagSF << endl;
	    // }

	  // DR
	  vector<TLorentzVector> tb, ub, tl, ul, bj, lj, aj;
	  unsigned int ntbjets = 0, ntcjets = 0, ntljets = 0, nttjets = 0;
	  for(unsigned int nj=0; nj<qpt.size(); nj++) {
	    TLorentzVector tmp;
	    tmp.SetPtEtaPhiE(qpt.at(nj), qeta.at(nj), qphi.at(nj), qE.at(nj));
	    aj.push_back(tmp);
	    if(abs(qpdg.at(nj)) == 5) {
	      bj.push_back(tmp);
	      if(qtagw.at(nj) > 0.7892) {
		tb.push_back(tmp);
		ntbjets++;
	      } else ub.push_back(tmp);
	    } else if(abs(qpdg.at(nj)) == 4) {
	      if(qtagw.at(nj) > 0.7892) ntcjets++;
	    } else if(abs(qpdg.at(nj)) == 0) {
	      lj.push_back(tmp);
	      if(qtagw.at(nj) > 0.7892) {
		tl.push_back(tmp);
		ntljets++;
	      } else ul.push_back(tmp);
	    } else if(abs(qpdg.at(nj)) == 15 && qtagw.at(nj) > 0.7892) nttjets++;
	  }

	  int Nttjets = 100*ntbjets+10*ntcjets+ntljets;
	  if(Nttjets > 549) Nttjets = 549;

	  // cout << "ContTRF done" << endl;
	  // unsigned int nhist = (njets-1)*(njets-1)/2.+3*(njets-1)/2. + nBjets;
	  unsigned int nhist = 5*(njets-4) + nBjets;
	  // if(nBjets == 4) cout << "njets = " << njets << " nBjets = " << nBjets << "  and before = " << savedNBjets << "  hist no = " << nhist << "  name file = " << mapHist[sampl][cals.at(ical)].at(nhist).at(0)->GetName() <<  "  event = " << eventNum <<  endl;
	  mapHist[sampl][cals.at(ical)].at(nhist).at(0)->Fill(HT/1000.,weight*btagSF);
	  unsigned int nbpl = (njets+1 > 5) ? 5 : njets+1;
	  // int nbpl = (njets+1 > 7) ? 7 : njets+1;
	  for(unsigned int mj=1; mj<nbpl; mj++) {
	    mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-3)->Fill(qpt.at(mj-1)/1000.,weight*btagSF);
	    mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-2)->Fill(qeta.at(mj-1),weight*btagSF);
	    mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-1)->Fill(qphi.at(mj-1),weight*btagSF);
	    if(btagSF == 1. || cals.at(ical).Contains("Cont")) 
	      mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj)->Fill(BtagOP::getLCbin(qtagw.at(mj-1),"LCcontMV1"),weight*btagSF);
	    else mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj)->Fill(BtagOP::getLCbin(qtagw.at(mj-1),"LCcumMV1"),weight*btagSF);
	  }
          if(ntjets == 0) mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-3)->Fill(Ntjets,weight*btagSF);
          else mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-3)->Fill(0.,weight*btagSF);
          if(nttjets == 0) mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-2)->Fill(Nttjets,weight*btagSF);
          else mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-2)->Fill(0.,weight*btagSF);
	  mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-1)->Fill(HT/1000.,weight*btagSF);

	  // cout << "DT done" << endl;
	}
	// mapHist[sampl]["CumDT"].at(5*(njets-4) + nBjets).at(0)->Fill(HT/1000.);
	// for(unsigned int mj=1; mj<5; mj++) {
	//   mapHist[sampl]["CumDT"].at(5*(njets-4) + nBjets).at(3*mj-2)->Fill(jpt->at(mj-1)/1000.);
	//   mapHist[sampl]["CumDT"].at(5*(njets-4) + nBjets).at(3*mj-1)->Fill(jeta->at(mj-1));
	//   mapHist[sampl]["CumDT"].at(5*(njets-4) + nBjets).at(3*mj)->Fill(BtagOP::getLCbin(jtagw->at(mj-1),"LCcontMV1"));
	// }
	// cout << "CumDT done" << endl;
	// cout << "entries (pt) =  "<< mapHist["CumDT"].at(0).at(0)->GetEntries() << endl;

	// mapHist[sampl]["ContDT"].at(5*(njets-4) + nBjets).at(0)->Fill(HT/1000.,cbSF);
	// for(unsigned int mj=1; mj<5; mj++) {
	//   mapHist[sampl]["ContDT"].at(5*(njets-4) + nBjets).at(3*mj-2)->Fill(jpt->at(mj-1)/1000.,cbSF);
	//   mapHist[sampl]["ContDT"].at(5*(njets-4) + nBjets).at(3*mj-1)->Fill(jeta->at(mj-1),cbSF);
	//   mapHist[sampl]["ContDT"].at(5*(njets-4) + nBjets).at(3*mj)->Fill(BtagOP::getLCbin(jtagw->at(mj-1),"LCcontMV1"),cbSF);
	// }

	else if(cals.at(ical).Contains("Cum") && cals.at(ical).Contains("TRF")) {
	  // cout << "in TRF" << endl;
	  // need to add RW for TRF cum...
	  vector<double> trfcum_ex, trfcum_in;
	  vector<vector<int> > tcbins_ex, tcbins_in;
	  vector<double> prw_ex, prw_in;
	  vector<double> tbrw_ex, tbrw_in;
	  TString calib = "CumDef";
	  if(cals.at(ical) != "CumTRF") {
	    calib = cals.at(ical);
	    calib.ReplaceAll("TRF","");
	  }
	  cbc.getTRFweights(string(calib),7,trfcum_ex,trfcum_in);
	  cbc.setAllPermutations(string(calib),perm_ex,perm_in);
	  cbc.setAllTagBins(string(calib),tbins_ex, tbins_in);
	  cbc.getAllTagBins(string(calib),tcbins_ex, tcbins_in);
	  cbc.getAllPermutationsRW(string(calib),prw_ex, prw_in);
	  cbc.getAllTagBinsRW(string(calib),tbrw_ex, tbrw_in);

	  vector<double> extrap_ex, extrap_in;
	  cbc.getTRFextrapUncertainties(string(calib),4,extrap_ex, extrap_in, true);

	  // // syst example
	  // cout << "nom = " << trfcum_in.at(2)*prw_in.at(2)*tbrw_in.at(2) << endl;
	  // for(unsigned int iev=1; iev < cbc.getNumEV(5,string(calib))+1; iev++) {
	  //   cout << "B: iev = " << iev << "  SFup = " << cbc.getTRFweightWithPermRW(string(calib),2, true, 5,iev,false) 
	  // 	   << "  SFdown = " << cbc.getTRFweightWithPermRW(string(calib),2,true,5,-iev,false) << endl;
	  // }
	  // for(unsigned int iev=1; iev < cbc.getNumEV(4,string(calib))+1; iev++) {
	  //   cout << "C: iev = " << iev << "  SFup = " << cbc.getTRFweightWithPermRW(string(calib),2, true, 4,iev,false) 
	  // 	   << "  SFdown = " << cbc.getTRFweightWithPermRW(string(calib),2,true,4,-iev,false) << endl;
	  // }
	  // for(unsigned int iev=1; iev < cbc.getNumEV(0,string(calib))+1; iev++) {
	  //   cout << "L: iev = " << iev << "  SFup = " << cbc.getTRFweightWithPermRW(string(calib),2, true, 0,iev,false) 
	  // 	   << "  SFdown = " << cbc.getTRFweightWithPermRW(string(calib),2,true,0,-iev,false) << endl;
	  // }
	  if(highptbjet || highptcjet || highptljet) cout << "nom = " << btagSF << "   extrap up = " << cbc.getTRFextrapUncertainty(string(calib),2,true,true)
							  << "  down = " << cbc.getTRFextrapUncertainty(string(calib),2,true,false) << endl;
	    
	  // } else {
	  //   trfcum_ex = *TRFweight_ex, trfcum_in = *TRFweight_in;
	  //   cbc.setAllTagBins(string(calib),*TRFTagW_ex,*TRFTagW_in);
	  //   cbc.getAllTagBins(string(calib),tcbins_ex, tcbins_in);
	  //   // tcbins_ex = *TRFTagW_ex, tcbins_in = *TRFTagW_in;
	  //   prw_ex = vector<double>(perm_ex.size(),1), prw_in = vector<double>(perm_in.size(),1);
	  //   tbrw_ex = vector<double>(tcbins_ex.size(),1), tbrw_in = vector<double>(tcbins_in.size(),1);
	  // }
	  // for(unsigned int ip=0; ip<prw_ex.size(); ip++) cout << "cal = " << calib << "  prw = " << prw_ex.at(ip) << "  trw = " << tbrw_ex.at(ip) << endl;
	  // for(unsigned int ib=0; ib<5; ib++) {
	  unsigned int nbpl = (njets+1 > 5) ? 5 : njets+1;
	  // int nbpl = (njets+1 > 7) ? 7 : njets+1;
	  // for(unsigned int ib=0; ib<njets+1; ib++) {
	  for(unsigned int ib=0; ib<5; ib++) {
	    // unsigned int nhist = (njets-1)*(njets-1)/2.+3*(njets-1)/2. + ib;
	    unsigned int nhist = 5*(njets-4) + ib;
	    // vector<bool> istag = (ib < 4) ? *TRFChosenTag_ex->at(ib) : *TRFChosenTag_ex->at(ib);
	    vector<bool> istag = (ib < 4) ? perm_ex.at(ib) : perm_in.at(ib);
	    unsigned int ntbjets = 0, ntcjets = 0, ntljets = 0, nttjets = 0;
	    for(unsigned int it=0; it<istag.size(); it++) {
	      if(!istag.at(it)) continue;
	      if(abs(qpdg.at(it)) == 5) ntbjets++;
	      else if(abs(qpdg.at(it)) == 4) ntcjets++;
	      else if(abs(qpdg.at(it)) == 0) ntljets++;
	      else if(abs(qpdg.at(it)) == 15) nttjets++;
	    }
	    int Nttjets = 100*ntbjets+10*ntcjets+ntljets;
	    if(Nttjets > 549) Nttjets = 549;

	    if(ib != 4) {
	      // mapHist[sampl]["CumTRF"].at(nhist).at(0)->Fill(HT/1000.,trfw_ex.at(ib));
	      mapHist[sampl][cals.at(ical)].at(nhist).at(0)->Fill(HT/1000.,weight*trfcum_ex.at(ib));
	      for(unsigned int mj=1; mj<nbpl; mj++) {
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-3)->Fill(qpt.at(mj-1)/1000.,weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-2)->Fill(qeta.at(mj-1),weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-1)->Fill(qphi.at(mj-1),weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj)->Fill(tcbins_ex.at(ib).at(mj-1),weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		// mapHist[sampl][cals.at(ical)].at(nhist).at(3*mj)->Fill(tbins_ex.at(ib).at(mj-1),trfw_ex.at(ib));
	      }
	      // cout << "dans trueFlavs = " << weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib) << "  NTjets = " << Ntjets << endl;
	      if(ntjets == 0) mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-3)->Fill((float)Ntjets,weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	      else mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-3)->Fill(0.,weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	      if(nttjets == 0) mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-2)->Fill((float)Nttjets,weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	      else mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-2)->Fill(0.,weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	      mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-1)->Fill(HT/1000.,weight*trfcum_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	    } else {
	      mapHist[sampl][cals.at(ical)].at(nhist).at(0)->Fill(HT/1000.,weight*trfcum_in.at(ib));
	      for(unsigned int mj=1; mj<nbpl; mj++) {
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-3)->Fill(qpt.at(mj-1)/1000.,weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-2)->Fill(qeta.at(mj-1),weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj-1)->Fill(qphi.at(mj-1),weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
		mapHist[sampl][cals.at(ical)].at(nhist).at(4*mj)->Fill(tcbins_in.at(ib).at(mj-1),weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	      }
	      if(ntjets == 0) mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-3)->Fill(Ntjets,weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	      else mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-3)->Fill(0.,weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	      if(nttjets == 0) mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-2)->Fill(Nttjets,weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	      else mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-2)->Fill(0.,weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	      mapHist[sampl][cals.at(ical)].at(nhist).at(nbhist-1)->Fill(HT/1000.,weight*trfcum_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	    }
	  }
	  // cout << "TRF done" << endl;
	}

	else {
	  TString calib = cals.at(ical);
	  calib.ReplaceAll("TRF_rw","");
	  // cout << "cal = " << calib << endl;
	  string caliB(calib);
	  vector<double> trfc_ex, trfc_in;
	  cbc.getTRFweights(caliB,7,trfc_ex,trfc_in);
	  // cbc.setAllPermutations(caliB,*TRFChosenTag_ex,*TRFChosenTag_in);
	  // cbc.setAllTagBins(caliB,*TRFTagW_ex, *TRFTagW_in, true);
	  cbc.setAllPermutations(caliB,perm_ex,perm_in);
	  cbc.setAllTagBins(caliB,tbins_ex, tbins_in, true);
	  vector<vector<int> > tcbins_ex, tcbins_in;
	  cbc.getAllTagBins(caliB,tcbins_ex, tcbins_in);
	  vector<double> prw_ex, prw_in;
	  cbc.getAllPermutationsRW(caliB,prw_ex, prw_in);
	  vector<double> tbrw_ex, tbrw_in;
	  cbc.getAllTagBinsRW(caliB,tbrw_ex, tbrw_in);

	  // for(unsigned int ib=0; ib<5; ib++) {
	  unsigned int nbpl = (njets+1 > 5) ? 5 : njets+1;
	  // int nbpl = (njets+1 > 7) ? 7 : njets+1;
	  // for(unsigned int ib=0; ib<njets+1; ib++) {
	  for(unsigned int ib=0; ib<5; ib++) {
	    // unsigned int nhist = (njets-1)*(njets-1)/2.+3*(njets-1)/2. + ib;
	    unsigned int nhist = 5*(njets-4) + ib;

	    vector<bool> istag = (ib < 4) ? perm_ex.at(ib) : perm_in.at(ib);

	    if(ib != 4) {
	      mapHist[sampl][calib+"TRF_rw"].at(nhist).at(0)->Fill(HT/1000.,trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	      // for(unsigned int mj=1; mj<5; mj++) {
	      for(unsigned int mj=1; mj<nbpl; mj++) {
		// mapHist[sampl][calib+"TRF_rw"].at(nhist).at(3*mj-2)->Fill(jpt->at(mj-1)/1000.,trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		// mapHist[sampl][calib+"TRF_rw"].at(nhist).at(3*mj-1)->Fill(jeta->at(mj-1),trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		// mapHist[sampl][calib+"TRF_rw"].at(nhist).at(3*mj)->Fill(tcbins_ex.at(ib).at(mj-1),trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj-3)->Fill(qpt.at(mj-1)/1000.,trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj-2)->Fill(qeta.at(mj-1),trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj-1)->Fill(qphi.at(mj-1),trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj)->Fill(tcbins_ex.at(ib).at(mj-1),trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	      }
	    } else {
	      mapHist[sampl][calib+"TRF_rw"].at(nhist).at(0)->Fill(HT/1000.,trfc_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
	      for(unsigned int mj=1; mj<nbpl; mj++) {
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj-3)->Fill(qpt.at(mj-1)/1000.,trfc_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj-2)->Fill(qeta.at(mj-1),trfc_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj-1)->Fill(qphi.at(mj-1),trfc_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));
		mapHist[sampl][calib+"TRF_rw"].at(nhist).at(4*mj)->Fill(tcbins_in.at(ib).at(mj-1),trfc_in.at(ib)*prw_in.at(ib)*tbrw_in.at(ib));		
	      }
	    }
	  }
	}
	
      }

    } else { // continuous file
      // cout << "continuous file" << endl;
      for(unsigned int ib=0; ib<5; ib++) {
	mapHist[sampl]["ContTRF"].at(5*(njets-4) + ib).at(0)->Fill(HT/1000.,trfw_ex.at(ib));
	// cout << "ivec = " << 5*(njets-4) + ib << endl;
	// histVec.at(5*(njets-4) + ib).at(0)->Fill(jpt->at(0)/1000.,trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	// histVec.at(5*(njets-4) + ib).at(1)->Fill(jeta->at(0),trfc_ex.at(ib)*prw_ex.at(ib)*tbrw_ex.at(ib));
	unsigned int nbpl = (njets+1 > 5) ? 5 : njets+1;
	for(unsigned int mj=1; mj<nbpl; mj++) {
	  mapHist[sampl]["ContTRF"].at(5*(njets-4) + ib).at(3*mj-2)->Fill(qpt.at(mj-1)/1000.,trfw_ex.at(ib));
	  mapHist[sampl]["ContTRF"].at(5*(njets-4) + ib).at(3*mj-1)->Fill(qeta.at(mj-1),trfw_ex.at(ib));
	  mapHist[sampl]["ContTRF"].at(5*(njets-4) + ib).at(3*mj)->Fill(BtagOP::getLCbin(TRFTagW_ex->at(ib).at(mj-1),"LCcontMV1"),trfw_ex.at(ib));
	}
      }
      
    } 
   // cout << "ContDT_rw done" << endl;
    trfw = eventNum;
    // trfw2 = tbrw1;
    // trfw = tbrwC_ex.at(2);
    // trfw2 = tbrw_ex.at(2);

    otree->Fill();

    // for(unsigned int ical=0; ical<cals.size(); ical++) {
    //   cout << "cal = " << cals.at(ical)  << "  channels = " <<  mapHist[cals.at(ical)].size() << endl;
    //   for(unsigned int nc=0; nc<mapHist[cals.at(ical)].size(); nc++) {
    // 	cout << "nbre de dist = " << mapHist[cals.at(ical)].at(nc).size() << endl;
    // 	for(unsigned int nd=0; nd<mapHist[cals.at(ical)].at(nc).size(); nd++) {
    // 	  cout << "hist = " << mapHist[cals.at(ical)].at(nc).at(nd)->GetName() << endl;}
    //   }
    // }
  }    
  // string cbccase = "cumCalc";
  // if(isCont) cbccase = "contCalc";
  // TFile *ofich = TFile::Open(("ofile_"+inFile+"_"+cbccase+".root").c_str(),"recreate");

  // cout << "entries (pt) =  "<< mapHist["CumDT"].at(0).at(0)->GetEntries() << endl;
  // cout << "avant saing" << endl;
  cout << "avant save file " << inFile << endl;
  for(unsigned int isamp=0; isamp<samp.size(); isamp++) {
    for(unsigned int ical=0; ical<cals.size(); ical++) {
      TString sampl = "";
      if(samp.at(isamp) != "samp") sampl = "_"+samp.at(isamp);
      TFile *ofichn = TFile::Open((TString)odir+"ofile_"+inFile+"_"+cals.at(ical)+sampl+".root","recreate");
      ofichn->cd();
      // cout << "file = " << "ofile_"+inFile+"_"+cals.at(ical)+".root" << "  nbre channels = " << mapHist[cals.at(ical)].size() << endl;
      for(unsigned int nc=0; nc<mapHist[samp.at(isamp)][cals.at(ical)].size(); nc++) {
	// cout << "nbre de dist = " << mapHist[cals.at(ical)].at(nc).size() << endl;
	for(unsigned int nd=0; nd<mapHist[samp.at(isamp)][cals.at(ical)].at(nc).size(); nd++) {
	  // cout << "cal = " << cals.at(ical) << "  nc = " << nc << "  nd = " << nd << endl;
	  // cout << "hist = " << mapHist[cals.at(ical)].at(nc).at(nd)->GetName() << endl;
	  TString hname = mapHist[samp.at(isamp)][cals.at(ical)].at(nc).at(nd)->GetName();
	  hname.ReplaceAll("_"+cals.at(ical)+"_"+inFile+sampl,"");
	  mapHist[samp.at(isamp)][cals.at(ical)].at(nc).at(nd)->SetName(hname);
	  mapHist[samp.at(isamp)][cals.at(ical)].at(nc).at(nd)->Write();
	}
      }
      ofichn->Close();
    }
  }
  ofich->cd();
  otree->Write();
  h_mv1_1->Write();
  h_mv1_1_noRW->Write();
  h_mv1_1_notbRW->Write();
  h_mv1_1_in->Write();
  // ofich->Close();
}

int main (int argc, char** argv) {

  string odir = "";
  int first = 0, last = -1;
  string lepton = "muon";
  int c;
  while (--argc > 0 && (*++argv)[0] == '-' ) {
    c = *++argv[0];
    switch (c) {
    case 'o':
      odir = *++argv;
      --argc;
      break;
    case 'f':
      first = atoi(*++argv);
      --argc;
      break;
    case 'l':
      last = atoi(*++argv);
      --argc;
      break;
    case 'L':
      lepton = *++argv;
      --argc;
      break;
    default:
      cout << "No option required, you need to at least precise you jobOptions" << endl;
      break;
    }
  }
  cout << "doBtagRW dans util" << endl;  
  // BtagOP::setMidTagW();
  cout << "nbre de calib = " << BtagOP::op_TagW.size() << "  et mid = " << BtagOP::mid_TagW.size() << endl;
  // TRFinterface cbc("share/calibConfig.txt");
  string pathToConf = gSystem->Getenv("ROOTCOREBIN");
  if(pathToConf == "") cout << "Issue in the ROOTCORBIN path" << endl;
  cout << "pathToConf = " << pathToConf << "  full path = " << pathToConf+"/data/BtaggingTRFandRW/calibConfig.txt" << endl;
  TRFinterface cbc(pathToConf+"/data/BtaggingTRFandRW/calibConfig.txt",0.7892,"AntiKt4TopoLCJVF0_5",true);
  // TRFinterface cbc("/afs/cern.ch/work/e/eve/RootCore2/BtaggingTRFandRW/share/calibConfig.txt",0.7892,"AntiKt4TopoLCJVF0_5",true);
  // cbc.setRwSystForPermChoice(false);
  // cbc.setRwSystForTagBinsChoice(false);

  // cbc.setTestMode(true);

  cout << "[32mNbre de EV for b jets= " << cbc.getNumEV(5,"CumDef") << "[0m" << endl;

  vector<double> vpt;
  vpt.push_back(20), vpt.push_back(30), vpt.push_back(60), vpt.push_back(90), vpt.push_back(140), vpt.push_back(200), vpt.push_back(300);
  // double teta=0.;
  // for(unsigned int i=0; i<vpt.size()-1; i++) {
  //   double pt = (vpt.at(i)+vpt.at(i+1))/2.;  // vpt.at(i) + 
  //   cout << "CUM: SF = " << cbc.getSF(pt*1000., teta, 5, 0.7892, "CumDef") << endl;
  //   cout << "CUM: Eff = " << cbc.getEff(pt*1000., teta, 5, 0.7892, "CumDef") << endl;
  //   cout << "CONT: SF = " << cbc.getSF(pt*1000., teta, 5, 0.7892, "ContDef") << endl;
  //   cout << "CONT: Eff = " << cbc.getEff(pt*1000., teta, 5, 0.7892, "ContDef") << endl;
  // }

  // vector<double> pt = {25000., 32000., 121000.};
  // vector<double> eta = {0.2, 1.1, 2.3};
  // vector<int> pdg = {5, -4, 0};
  // vector<double> tagw = {0.9998, 0.77, 0.003};
  // cbc.setJets(pt, eta, pdg, tagw);

  // double test = cbc.getTRFweight("CumDef");

  TFile *fcum = NULL; //, *fcont = NULL;
  TTree *tcum = NULL; //, *tcont = NULL;

  // TFile *fcum = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_cumulative_OutputHisto.root").c_str(),"read");
  // TFile *fcont = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_continuous_OutputHisto.root").c_str(),"read");
  // TFile *fcum = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_cumAllEvts_OutputHisto.root").c_str(),"read");
  // TFile *fcont = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_contAllEvts_OutputHisto.root").c_str(),"read")// ;

  // TFile *fcont = TFile::Open("/afs/cern.ch/work/e/eve/RootCore2/irfiles/ttbar117050_nominal_contAllEvts_OutputHisto.root","read");
  // TFile *fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_VLQ/MUON/ttbar117050_nominal_OutputHisto.root","read");
  cout << "lepton = " << lepton << endl;
  if(lepton == "muon") {
    cout << "dans muon"  << endl;
    // fcum = TFile::Open("/nfs/at3/scratch2/emenedeu/HistogrammerOutputs/MV1rescalTest_260314/MUON/ttbar117050_nominal_cumAllEvts_OutputHisto.root","read");
    // fcont = TFile::Open("/nfs/at3/scratch2/emenedeu/HistogrammerOutputs/MV1rescalTest_260314/MUON/ttbar117050_nominal_contAllEvts_OutputHisto.root","read");
    // fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_VLQ/MUON/ttbar117050_fast_nominal_OutputHisto.root","read");
    fcum = TFile::Open("/nfs/at3/scratch2/emenedeu/HistogrammerOutputs/btagMaps_101014_wPartJets/TEST/ttbar117050_fast_MUON_nominal_OutputHisto_merged.root","read");
    // fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_VLQ/MUON/ttH125_nominal_OutputHisto.root","read");
    // fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_SherpaNLO/MUON/ttbar5860_fast_nominal_OutputHisto.root","read");
    // tcum = (TTree*)fcum->Get("Muon/4jetin25252525_0elecex25topcommonetacommon_1muonex25topcommonetacommon/0btagin0.7892MV1/atree");
    tcum = (TTree*)fcum->Get("atree");
    // tcont = (TTree*)fcont->Get("Muon/4jetin25252525_0elecex25topcommonetacommon_1muonex25topcommonetacommon/0btagin0.7892MV1/atree");

  } else if(lepton == "electron" || lepton == "ele") {
    
    // fcum = TFile::Open("/nfs/at3/scratch2/emenedeu/HistogrammerOutputs/MV1rescalTest_260314/ELE/ttbar117050_nominal_cumAllEvts_OutputHisto.root","read");
    // fcont = TFile::Open("/nfs/at3/scratch2/emenedeu/HistogrammerOutputs/MV1rescalTest_260314/ELE/ttbar117050_nominal_contAllEvts_OutputHisto.root","read");
    // fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_VLQ/ELE/ttbar117050_fast_nominal_OutputHisto.root","read");
    fcum = TFile::Open("/nfs/at3/scratch2/emenedeu/HistogrammerOutputs/btagMaps_101014_wPartJets/TEST/ttbar117050_fast_ELE_nominal_OutputHisto_merged.root","read");
    // fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_VLQ/ELE/ttH125_nominal_OutputHisto.root","read");
    // fcum = TFile::Open("/nfs/pic.es/user/j/jmontejo/scratch/Histogrammer_files/V24_SherpaNLO/ELE/ttbar5860_fast_nominal_OutputHisto.root","read");
    // tcum = (TTree*)fcum->Get("Electron/4jetin25252525_1elecex25topcommonetacommon_0muonex25topcommonetacommon/0btagin0.7892MV1/atree");
    tcum = (TTree*)fcum->Get("atree");
    // tcont = (TTree*)fcont->Get("Electron/4jetin25252525_1elecex25topcommonetacommon_0muonex25topcommonetacommon/0btagin0.7892MV1/atree");
  }

  cout << "file = " << fcum->GetName() << endl;
  bool isttbar = false;
  if(TString(fcum->GetName()).Contains("ttbar117050")) isttbar = true;

  // TFile *fdil = TFile::Open("root://eosatlas//eos/atlas/atlascerngroupdisk/phys-higgs/HSG8/MiniML/ttbar/mc12_8TeV.117050.PowhegPythia_P2011C_ttbar.merge.NTUP_TOP.e1728_s1581_s1586_r3658_r3549_p1400/Run_117050_ML_7B.root");
  // TTree *tdil = (TTree*)fdil->Get("mini");
  // if(tcum->GetEntries() != tcont->GetEntries()) cout << "[32mNot same number of entries -> strange[0m" << endl;
  // cout << "tcum entries = " << tcum->GetEntries() << endl;

  if(odir != "") {
    gSystem->Exec(("mkdir -p "+odir).c_str());
    if(!TString(odir).EndsWith("/")) odir += "/";
  }

  TFile *ofich = TFile::Open((odir+"ofile.root").c_str(),"recreate");
  // TFile *ofich = TFile::Open("ofile_dil.root","recreate");
  loopOnTree(tcum, cbc, false, "cumFile",odir,first, last, isttbar, ofich);
  // // loopOnTree(tcum, cbc, true, "cumFile");
  // loopOnTree(tcont, cbc, true,"contFile",odir,first, last, isttbar, ofich);
  // loopOnTree(tcont, cbc, false,"contFile");
  // loopOnTree(tdil, cbc, true,"dilFile",ofich);
  ofich->Close();
  return 0;
}
