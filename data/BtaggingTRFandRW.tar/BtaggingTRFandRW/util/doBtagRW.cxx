#include <iostream>
#include "BtaggingTRFandRW/BtagOP.h"
#include "BtaggingTRFandRW/TRFinterface.h"

#include <TFile.h>
#include <TTree.h>
#include <TSystem.h>

#include <vector>

using namespace std;

void loopOnTree(TTree *tree, TRFinterface cbc, bool isCont, string inFile, int first, int last, TFile *ofich)
{
  string cal = "CumDef", cal2 = "ContDef";
  if(isCont) cal = "ContDef", cal2 = "CumDef";

  double trfw=0, trfw2=0;
  vector<double> *trf_ex=0, *trf_in=0;

  vector<double> *jpt=0, *jeta=0, *jtagw=0;
  vector<int> *jpdg=0;
  vector<double> *TRFweight_in=0, *TRFweight_ex=0;
  vector<vector<bool> > *TRFChosenTag_in=0, *TRFChosenTag_ex=0;
  vector<vector<double> > *TRFTagW_in=0, *TRFTagW_ex=0;
  float btagSF=0.;

  // vector<vector<double> > *trfsys_ex=0, *trfsys_in=0;
  vector<vector<double> > trfsys_ex, trfsys_in;
  // std::vector<std::vector<int> > *ptrfsys_ex=NULL, *ptrfsys_in=NULL;
  // trfsys_ex->clear(); 
  // cout << "size du vec = " << ptrfsys_ex->size() << endl;
  cout << "size du vec = " << trfsys_ex.size() << endl;
  unsigned int eventNum = 0;
  tree->SetBranchStatus("*",0);
  tree->SetBranchStatus("EventNumber",1);
  tree->SetBranchStatus("jet_*",1);
  tree->SetBranchStatus("TRFMCweight_*",1);
  tree->SetBranchStatus("TRFChosenTag_*",1);
  tree->SetBranchStatus("TRFDiscreteBTagWeight_*",1);
  tree->SetBranchStatus("BtagWeight",1);
  
  // tree->SetBranchAddress("jet_pt",&jpt);
  tree->SetBranchAddress("jet_pt",&jpt);
  tree->SetBranchAddress("jet_eta",&jeta);
  tree->SetBranchAddress("jet_btag_weight",&jtagw);
  tree->SetBranchAddress("jet_trueflav",&jpdg);
  tree->SetBranchAddress("EventNumber",&eventNum);
  tree->SetBranchAddress("TRFMCweight_ex",&TRFweight_ex);
  tree->SetBranchAddress("TRFMCweight_in",&TRFweight_in);
  tree->SetBranchAddress("TRFChosenTag_ex",&TRFChosenTag_ex);
  tree->SetBranchAddress("TRFChosenTag_in",&TRFChosenTag_in);
  tree->SetBranchAddress("TRFDiscreteBTagWeight_ex",&TRFTagW_ex);
  tree->SetBranchAddress("TRFDiscreteBTagWeight_in",&TRFTagW_in);
  tree->SetBranchAddress("BtagWeight",&btagSF);

  string cbccase = "cumCalc";
  if(isCont) cbccase = "contCalc";
  TTree *otree = new TTree(("otree"+inFile+"_"+cbccase).c_str(),("otree"+inFile+"_"+cbccase).c_str());
  otree->Branch("trfw",&trfw);
  otree->Branch("trfw2",&trfw2);
  otree->Branch("trf_ex",&trf_ex);
  otree->Branch("trf_in",&trf_in);

  // TH1F *h_nbjets = new TH1F("h_nbjets","nbjets;# b-jets",7,0,7);
  TH1F *h_mv1_1 = new TH1F(("h_mv1_1"+inFile+"_"+cbccase).c_str(),"mv1_1;MV1 jet_{1}",5,0,5);
  TH1F *h_mv1_1_noRW = new TH1F(("h_mv1_1_noRW"+inFile+"_"+cbccase).c_str(),"mv1_1_noRW;MV1 jet_{1} (no perm and tagb rw)",5,0,5);
  TH1F *h_mv1_1_notbRW = new TH1F(("h_mv1_1_notbRW"+inFile+"_"+cbccase).c_str(),"mv1_1_noRW;MV1 jet_{1} (no tagb rw)",5,0,5);
  TH1F *h_mv1_1_in = new TH1F(("h_mv1_1_in"+inFile+"_"+cbccase).c_str(),"mv1_1_in;MV1 jet_{1} (initial)",5,0,5);

  if(last == -1) last = tree->GetEntries();
  for(Long_t i=first; i<last; i++) {
    tree->GetEntry(i);
    // if(eventNum != 10337436) continue;
    // cout << "event number = " << eventNum << endl;
    // cout << "leading pt = " << jpt->at(0) << "  eta = " << jeta->at(0) << "  jpdg = " << jpdg->at(0) << "  tagw = " << jtagw->at(0) << endl;
    cbc.setJets(*jpt, *jeta, *jpdg, *jtagw);
    cbc.setSeed(eventNum);
    // double retest = cbc.getTRFweight(cal,3,false);
    // double retest2 = cbc.getTRFweight(cal2,3,true);
    cbc.getTRFweights("CumDef",7,*trf_ex,*trf_in);
    // cbc.getTRFweights(7,*trf_ex,*trf_in);
    // cout << "Exclusive TRF = " << retest << "  for 3 btags" << endl;
    // trfw = retest;
    // trfw2 = TRFweight_in->at(3)/retest*retest2;
    vector<vector<bool> > perm_ex, perm_in;

    // cbc.chooseTagPermutation(7,perm_ex, perm_in);
    // cbc.chooseTagPermutation("ContDef",7,perm_ex, perm_in);
    // cbc.chooseTagPermutation(cal2,7,perm_ex, perm_in);
    unsigned int nb = (TRFweight_ex->size() < trf_ex->size()) ? TRFweight_ex->size() : trf_ex->size() ;
    for(unsigned int j=0; j<nb; j++) {
      cout << "TRFweight ex for nbtags = " << j << " = " <<  TRFweight_ex->at(j) << "  and TRFweight in = " << TRFweight_in->at(j) 
    	   << "  in tool, ex = " << trf_ex->at(j) << "  in = " << trf_in->at(j) << endl;
    }
    // try an exclusive permutation
    // vector<bool> perm = cbc.chooseTagPermutation(cal,3);
    // cout << "exclusive perm for 3 btag:" << endl;
    // for(unsigned int ip=0; ip<perm.size(); ip++) cout << perm.at(ip) << "  ";
    // cout << endl;
    // vector<int> tbins = cbc.chooseTagBins(cal,perm,false);
    // cout << "Tag w bins:" << endl;
    // for(unsigned int ib=0; ib<tbins.size(); ib++) cout << tbins.at(ib) << "  ";
    // cout << endl;
    // unsigned int nb = (TRFweight_ex->size() < trf_ex->size()) ? TRFweight_ex->size() : trf_ex->size() ;
    // for(unsigned int j=0; j<nb; j++) {
    //   cout << "TRFweight ex for nbtags = " << j << " = " <<  TRFweight_ex->at(j) << "  and TRFweight in = " << TRFweight_in->at(j) 
    // 	   << "  in tool, ex = " << trf_ex->at(j) << "  in = " << trf_in->at(j) << endl;
    // }
    // // try an exclusive permutation
    // vector<bool> perm = cbc.chooseTagPermutation(cal,3);
    // vector<bool> perm = perm_ex.at(3);
    // cout << "exclusive perm for 3 btag:" << endl;
    // for(unsigned int ip=0; ip<perm.size(); ip++) cout << perm.at(ip) << "  ";
    // cout << endl;
    // vector<int> tbins = cbc.chooseTagBins(cal,perm,false);
    // cout << "Tag w bins:" << endl;
    // for(unsigned int ib=0; ib<tbins.size(); ib++) cout << tbins.at(ib) << "  ";
    // cout << endl;
    // vector<double> tws = cbc.getTagWfromTagBins(cal,tbins);
    // cout << "Tag weights:" << endl;
    // for(unsigned int iw=0; iw<tws.size(); iw++) cout << tws.at(iw) << "  ";
    // cout << endl;
    // for(unsigned int ip=0; ip<perm_ex.size(); ip++) {
    //   cout << "tagged jets for case " << ip << ":   ";
    //   for(unsigned int ij=0; ij< perm_ex.at(ip).size(); ij++)
    // 	cout << perm_ex.at(ip).at(ij[m_calibMap[calib].jetCalAlg) << "  ";
    //   cout << endl;
    // }    
    // for(unsigned int ip=0; ip<perm_in.size(); ip++) {
    //   cout << "tagged jets for case inclusive" << ip << ":   ";
    //   for(unsigned int ij=0; ij< perm_in.at(ip).size(); ij++)
    // 	cout << perm_in.at(ip).at(ij) << "  ";
    //   cout << endl;
    // }
    
    // cout << "w perm = " << cbc.getPermutationRW(cal,perm,false,5,1,3) << "  cal = " << cal << endl;
    // cout << "w perm = " << cbc.getPermutationRW(cal,perm,true,5,1,3) << "  cal = " << cal << endl;
    // cbc.getTRFweights(cal,7,*trf_ex,*trf_in, 5, -4);
    // vector<bool> perm = TRFChosenTag_ex->at(3);
    // cout << "avant les choose" << endl;
    cbc.chooseTagPermutation("CumDef",7,perm_ex, perm_in);
    vector<vector<int> > bins_ex(7), bins_in(7);
    // cout << "avant choose tag bins" << endl;
    cbc.chooseTagBins("CumDef",bins_ex,bins_in);
    // cout << "tag bins chosen "<< endl;
    // cbc.chooseTagPermutation("CumDef",7,perm_ex, perm_in);
    // cout << "trf_ex(3) = " << trf_ex->at(3) << endl;
    // cbc.setAllPermutations("CumDef",perm_ex, perm_in);
    // cbc.setAllTagBins("CumDef",bins_ex, bins_in);
    // cbc.setPermutation("CumDef",perm_ex.at(3), false, 3);
    // cbc.setTagBins("CumDef",bins_ex.at(3),false,3);
    // cbc.getTRFweights("ContDef",7,*trf_ex,*trf_in);
    // cbc.setAllPermutations("ContDef",perm_ex, perm_in);
    // cbc.setAllTagBins("ContDef",bins_ex, bins_in);
    // double rw5m4 = cbc.getPermutationRW("ContDef",perm_in.at(1),true,5,-4,1);
    // cout << "avant la syst" << endl;
    // cbc.getTRFweights("CumDef",7,*trf_ex,*trf_in, 5, -4);
    // cout << "weight = " << cbc.getTRFweightWithPermRW("CumDef",3,false, 5, -4) << endl;
    // cout << "avant le RW" << endl;
    // double tbrw = cbc.getTagBinsRW("CumDef",bins_in.at(1),true,1, "CumDef", 5, -4);
    // cout << "getTagBinsRW done" << endl;

    cbc.getTRFweights("ContDef",7,*trf_ex,*trf_in);
    cbc.setAllPermutations("ContDef",perm_ex, perm_in);
    // cbc.setAllTagBins("ContDef",bins_ex, bins_in);
    // cout << "avant setAllTagBins" << endl;
    cbc.setAllTagBins("ContDef",bins_ex, bins_in, true);
    // cout << "[34mtag bins set[0m" << endl;
    vector<vector<int> > tcbins_ex, tcbins_in;
    cbc.getAllTagBins("ContDef",tcbins_ex, tcbins_in);
    double tbrwp = cbc.getPermutationRW("CumDef",false,2, "ContDef");
    double tbrw1 = cbc.getTagBinsRW("CumDef",false,2, "ContDef");
    // cout << "cum to cont done" << endl;

    // if(isCont) {
    //   double cbSF = cbc.getEvtContSF("ContDef");
    //   cout << "btagSF = " << btagSF << "  cbSF = " << cbSF << endl;
    // }
    // with syst
    // cbc.getTRFweights("ContDef",7,*trf_ex,*trf_in, 5, -4);
    // double tbrw2 = cbc.getTagBinsRW("CumDef",bins_in.at(1),true,1, "ContDef",5,-4);
    // double tbrw3 = cbc.getTagBinsRW("ContDef",bins_in.at(1),true,1, "ContDef",5,-4);
    // double tbrw4 = cbc.getTagBinsRW("ContDef",tcbins_in.at(1),true,1, "ContDef",5,-4);
    // cout << "nom RW = " << tbrw1 << "  syst cum to cont: " << tbrw2 << "  cont to cont = " << tbrw3 << "  nom rw * cont to cont = " << tbrw1*tbrw3 
    // 	 << "  cont2cont corr conf = " << tbrw4 << "  prod = " << tbrw1*tbrw4 << endl;
    //double tbrw5 = cbc.getTagBinsRW("ContDef",true,3, "ContDef",4,2);

    h_mv1_1->Fill(tcbins_ex.at(2).at(1),trf_ex->at(2)*tbrwp*tbrw1);
    h_mv1_1_noRW->Fill(tcbins_ex.at(2).at(1),trf_ex->at(2));
    h_mv1_1_notbRW->Fill(tcbins_ex.at(2).at(1),trf_ex->at(2)*tbrwp);

    vector<int> binsInFile_ex = cbc.getTagBinsfromTagW(cal,TRFTagW_ex->at(2));
    h_mv1_1_in->Fill(binsInFile_ex.at(1),TRFweight_ex->at(2));

    // double tbrw = cbc.getTagBinsRW("CumDef",bins_in.at(1),true,1, "ContDef"); //, 5, -4, 1);
    // cbc.getTRFweights("ContDef",7,*trf_ex,*trf_in, 5, 1);
    // double rw51 = cbc.getPermutationRW("ContDef",perm_ex.at(3),false,5,1,3);
    // double tbrw51 = cbc.getTagBinsRW("ContDef",bins_ex.at(3),false, 5, 1, 3);
    // cbc.setTagBins("CumDef",tbins,false,3);
    // cbc.setAllPermutations("CumDef",*TRFChosenTag_ex, *TRFChosenTag_in);
    // // cbc.getTRFweights("CumDef",7,*trf_ex,*trf_in);
    // // vector<bool> perm = perm_ex.at(3);
    // vector<bool> perm = TRFChosenTag_ex->at(3);
    // cbc.setTagBins("CumDef",TRFTagW_ex->at(3),false,3);
    // vector<double> trfs_ex, trfs_in;
    // cbc.getTRFweights("ContDef",7,trfs_ex,trfs_in);
    // cout << "avant permutation" << endl;
    // cbc.setPermutation("ContDef",perm_ex.at(3), false, 3);
    // cout << "avant settagbins" << endl;
    // cbc.setTagBins("ContDef",bins_ex.at(3),false,3);
    // cout << "RW" << endl;
    
    // double tbrw51 = cbc.getTagBinsRW("CumDef",bins_ex.at(0),false, "ContDef");
    // cout << "tbrw51 = " << tbrw51 << endl;
    // double rw51 = cbc.getPermutationRW("CumDef",perm,false,5,1,3);
    // cbc.getTRFweights("CumDef",7,*trf_ex,*trf_in, 5, -4);
    // double rw5m4 = cbc.getPermutationRW("CumDef",perm,false,5,-4,3);
    otree->Fill();

    // cout << "TEST: pt = 250000, eta = 2.25, tagw = 0.9847, pdg = 4  -> " << cbc.getSF(250000., 2.25, 4, 0.9847, "ContDef") << endl;
    // cout << "TEST: pt = 250000, eta = 1.75, tagw = 0.9847, pdg = 4  -> " << cbc.getSF(250000., 1.75, 4, 0.9847, "ContDef") << endl;
    // cout << "TEST: pt = 250000, eta = -1.75, tagw = 0.9847, pdg = 4  -> " << cbc.getSF(250000., -1.75, 4, 0.9847, "ContDef") << endl;
    // cout << "TEST: pt = 250000, eta = -2.25, tagw = 0.9847, pdg = 4  -> " << cbc.getSF(250000., -2.25, 4, 0.9847, "ContDef") << endl;
    // cout << "TEST: pt = 250000, eta = 2.25, tagw = 0.7992, pdg = 4  -> " << cbc.getSF(250000., 2.25, 4, 0.7992, "ContDef") << endl;
    // vector<double> trfs_ex, trfs_in;
    // cbc.getTRFweights("ContDef",7,trfs_ex,trfs_in);
    // cout << "avant permutation" << endl;
    // cbc.setPermutation("ContDef",perm_ex.at(3), false, 3);
    // cout << "avant settagbins" << endl;
    // cbc.setTagBins("ContDef",bins_ex.at(3),false,3);
    // cout << "RW" << endl;
    
    // double tbrw51 = cbc.getTagBinsRW("CumDef",bins_ex.at(0),false, "ContDef");
    // cout << "tbrw51 = " << tbrw51 << endl;
    // cbc.getTRFweights(cal,7,*trf_ex,*trf_in, 4, -5);
    // cbc.getTRFweights(cal,7,*trf_ex,*trf_in, 0, -3);

    // for(int iev=1; iev<(int)cbc.getNumEV(5,"CumDef")+1; iev++) {
    //   cbc.getTRFweights("CumDef",7,*trf_ex,*trf_in,5,iev);
    //   cout << "EV = " << iev << endl;
    //   for(unsigned int inb=0; inb<trf_ex->size(); inb++)
    // 	cout << "inb = " << inb << "  trf_ev = " << trf_ex->at(inb) << endl;
    // }
    // cout << "new we (5,2) = " << cbc.getTRFweightWithPermRW("ContDef",3,false, 5, 2) << endl;
    // cout << "new we (5,-2) = " << cbc.getTRFweightWithPermRW("ContDef",3,false, 5, -2) << endl;
    // cout << "size of trfsys_ev = " << trfsys_ex.size() << endl;
    // cbc.getTRFweightsForSyst("ContDef",7, trfsys_ex, trfsys_in, 5, true);
    // for(unsigned int jev=0; jev < trfsys_ex.size(); jev++) {
    //   cout << "b ev " << jev << " : " << endl;
    //   for(unsigned  int ib=0; ib < trfsys_ex.at(jev).size(); ib++)
    // 	cout << "ib = " << ib << "  trf = " << trfsys_ex.at(jev).at(ib) << endl;
    // }
    // cout << "size of trfsys_ev = " << trfsys_ex.size() << endl;
    // // cbc.getTRFweightsForSyst("CumDef",7, *trfsys_ex, *trfsys_in, 5, true);
    // cbc.getTRFweightsForSyst("CumDef",7, trfsys_ex, trfsys_in, 5, true);
    // for(unsigned int jev=0; jev < trfsys_ex.size(); jev++) {
    //   cout << "b ev " << jev << " : " << endl;
    //   for(unsigned  int ib=0; ib < trfsys_ex.at(jev).size(); ib++)
    // 	cout << "ib = " << ib << "  trf = " << trfsys_ex.at(jev).at(ib) << endl;
    // }
    // vector<vector<double> > *ptrfsys_ex = &trfsys_ex;
    // cout << "size du pointeur = " << ptrfsys_ex->size() << endl;
  }
  // string cbccase = "cumCalc";
  // if(isCont) cbccase = "contCalc";
  // TFile *ofich = TFile::Open(("ofile_"+inFile+"_"+cbccase+".root").c_str(),"recreate");
  ofich->cd();
  otree->Write();
  h_mv1_1->Write();
  h_mv1_1_noRW->Write();
  h_mv1_1_notbRW->Write();
  h_mv1_1_in->Write();
  // ofich->Close();
}

int main (int argc, char** argv) {

  string odir = "";
  int first = 0, last = -1;
  int c;
  while (--argc > 0 && (*++argv)[0] == '-' ) {
    c = *++argv[0];
    switch (c) {
    case 'o':
      odir = *++argv;
      --argc;
      break;
    case 'f':
      first = atoi(*++argv);
      --argc;
      break;
    case 'l':
      last = atoi(*++argv);
      --argc;
      break;
    default:
      cout << "No option required, you need to at least precise you jobOptions" << endl;
      break;
    }
  }
  cout << "doBtagRW dans util" << endl;  
  // BtagOP::setMidTagW();
  cout << "nbre de calib = " << BtagOP::op_TagW.size() << "  et mid = " << BtagOP::mid_TagW.size() << endl;
  // TRFinterface cbc("share/calibConfig.txt");
  string pathToConf = gSystem->Getenv("ROOTCOREBIN");
  if(pathToConf == "") cout << "Issue in the ROOTCORBIN path" << endl;
  cout << "pathToConf = " << pathToConf << "  full path = " << pathToConf+"/data/BtaggingTRFandRW/calibConfig.txt" << endl;
  TRFinterface cbc(pathToConf+"/data/BtaggingTRFandRW/calibConfig.txt",0.7892,"AntiKt4TopoLCJVF0_5",true);
  // TRFinterface cbc("/afs/cern.ch/work/e/eve/RootCore2/BtaggingTRFandRW/share/calibConfig.txt",0.7892,"AntiKt4TopoLCJVF0_5",true);
  // cbc.setRwSystForPermChoice(false);
  // cbc.setRwSystForTagBinsChoice(false);

  cout << "[32mNbre de EV for b jets= " << cbc.getNumEV(5,"CumDef") << "[0m" << endl;

  // vector<double> vpt = {20,30,60,90,140,200,300};
  // double teta=0.;
  // for(unsigned int i=0; i<vpt.size()-1; i++) {
  //   double pt = (vpt.at(i)+vpt.at(i+1))/2.;  // vpt.at(i) + 
  //   cout << "CUM: SF = " << cbc.getSF(pt*1000., teta, 5, 0.7892, "CumDef") << endl;
  //   cout << "CUM: Eff = " << cbc.getEff(pt*1000., teta, 5, 0.7892, "CumDef") << endl;
  //   cout << "CONT: SF = " << cbc.getSF(pt*1000., teta, 5, 0.7892, "ContDef") << endl;
  //   cout << "CONT: Eff = " << cbc.getEff(pt*1000., teta, 5, 0.7892, "ContDef") << endl;
  // }

  // vector<double> pt = {25000., 32000., 121000.};
  // vector<double> eta = {0.2, 1.1, 2.3};
  // vector<int> pdg = {5, -4, 0};
  // vector<double> tagw = {0.9998, 0.77, 0.003};
  // cbc.setJets(pt, eta, pdg, tagw);

  // double test = cbc.getTRFweight("CumDef");

  TFile *fcum = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_cumulative_OutputHisto.root").c_str(),"read");
  TFile *fcont = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_continuous_OutputHisto.root").c_str(),"read");
  // TFile *fcum = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_cumAllEvts_OutputHisto.root").c_str(),"read");
  // TFile *fcont = TFile::Open((pathToConf+"/data/BtaggingTRFandRW/ttbar117050_nominal_contAllEvts_OutputHisto.root").c_str(),"read");

  // TFile *fcum = TFile::Open("/afs/cern.ch/work/e/eve/RootCore2/irfiles/ttbar117050_nominal_cumAllEvts_OutputHisto.root","read");
  // TFile *fcont = TFile::Open("/afs/cern.ch/work/e/eve/RootCore2/irfiles/ttbar117050_nominal_contAllEvts_OutputHisto.root","read");
  TTree *tcum = (TTree*)fcum->Get("Muon/4jetin25252525_0elecex25topcommonetacommon_1muonex25topcommonetacommon/0btagin0.7892MV1/atree");
  TTree *tcont = (TTree*)fcont->Get("Muon/4jetin25252525_0elecex25topcommonetacommon_1muonex25topcommonetacommon/0btagin0.7892MV1/atree");
  if(tcum->GetEntries() != tcont->GetEntries()) cout << "[32mNot same number of entries -> strange[0m" << endl;
  // cout << "tcum entries = " << tcum->GetEntries() << endl;
  TFile *ofich = TFile::Open("ofile.root","recreate");
  loopOnTree(tcum, cbc, false, "cumFile",first, last,ofich);
  // loopOnTree(tcum, cbc, true, "cumFile");
  loopOnTree(tcont, cbc, true,"contFile",first, last,ofich);
  // loopOnTree(tcont, cbc, false,"contFile");
  return 0;
}
