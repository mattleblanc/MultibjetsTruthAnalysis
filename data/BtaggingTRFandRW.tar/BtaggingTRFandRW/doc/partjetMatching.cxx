// needed inputs:
// from jets: pt, eta, phi, trueflav (or pdg)
// from particle jets: pt, eta, phi, trueflav, id, count
// Also recalculate HFtype

vector<int> matchJetsAndPartjets(const vector<TVector3> &jets, const vector<TVector3> &pjets, const vector<unsigned int> &indpj, vector<int> &matchind)
{
  vector<int> matchrind(jets.size(),-1);
  for(unsigned int ij=0; ij<jets.size(); ij++) {
    for(unsigned int ipj=0; ipj<pjets.size(); ipj++) {
      if(jets.at(ij).DeltaR(pjets.at(ipj)) <= 0.3) {
	if(matchind.at(ij) != -1) {
	  if(jets.at(ij).DeltaR(pjets.at(ipj)) > jets.at(ij).DeltaR(pjets.at(matchind.at(ij)))) continue;
	  matchind.at(ij) = ipj;
	  matchrind.at(ij) = indpj.at(ipj);
	} else {
	  matchind.at(ij) = ipj;
	  matchrind.at(ij) = indpj.at(ipj);
	}
      }
    }
  }
  return matchrind;
}


std::vector<int> getMapIds(std::vector<double> &jpt, std::vector<double> &jeta, std::vector<double> &jphi, std::vector<int> &jpdg)
{
  vector<TVector3> tv3jets, tv3pjets;
  vector<unsigned int> indpj;
  TVector3 tmp;
  // matching particle jets
  for(unsigned int ij=0; ij<jpt.size(); ij++) {
    tmp.SetPtEtaPhi(jpt.at(ij),jeta.at(ij),jphi.at(ij));
    tv3jets.push_back(tmp);
  }
  unsigned int nb=0, nc=0;
  for(unsigned int ipj=0; ipj<partjet_pt->size(); ipj++) {
    if(partjet_pt->at(ipj) < 15000) continue;
    if(fabs(partjet_eta->at(ipj)) > 2.5) continue;
    tmp.SetPtEtaPhi(partjet_pt->at(ipj),partjet_eta->at(ipj),partjet_phi->at(ipj));
    indpj.push_back(ipj);
    tv3pjets.push_back(tmp);
    if(abs(partjet_trueflav->at(ipj)) == 5 && partjet_id->at(ipj) < 3) nb++;
    else if(abs(partjet_trueflav->at(ipj)) == 4 && partjet_id->at(ipj) > -3) nc++;
  }

  // new classification
  HFtype = 0;
  if(nb > 0) HFtype = 500;
  else if(nc > 0) HFtype = -500;

  // cout << "nbre de jets = " << jpt.size() << "   in tv3 = " << tv3jets.size() << "  part jets = " << partjet_pt->size() << "  in tv3 = " << tv3pjets.size() << "  pour int = " << indpj.size() << endl;
  vector<int> matchind(jpt.size(),-1);
  vector<int> matchrind = matchJetsAndPartjets(tv3jets, tv3pjets, indpj, matchind);
  vector<unsigned int> matchid(jpt.size(),0);
  vector<int> matchpdg(jpt.size(),0), matchqual(jpt.size(),0);
  // also look for double matches
  for(unsigned int ij=0; ij<matchind.size(); ij++) {
    if(matchind.at(ij) != -1) {
      for(unsigned int ik=ij+1; ik<matchind.size(); ik++) {
	if(matchind.at(ik) == matchind.at(ij)) {
	  if(abs(jpdg.at(ij)) > 3 && abs(jpdg.at(ik)) > 3) { // only in heavy flavour cases, light ones won't be degraded and same maps for top/W and others
	    if(partjet_count->at(matchrind.at(ij)) > 1) continue;  // 2 heavy quarks at beginning possible to get 2 HF jets...
	    if(tv3jets.at(ij).DeltaR(tv3pjets.at(matchind.at(ij))) < tv3jets.at(ik).DeltaR(tv3pjets.at(matchind.at(ik)))) { // ij will be matched
	      if(partjet_trueflav->at(matchrind.at(ij)) == jpdg.at(ij)) matchqual.at(ij) = 3;
	      if(partjet_trueflav->at(matchrind.at(ik)) == jpdg.at(ik)) matchqual.at(ik) = -3;
	      else matchqual.at(ik) = -1;
	    } else { // ik will be matched
	      if(partjet_trueflav->at(matchrind.at(ik)) == jpdg.at(ik)) matchqual.at(ik) = 3;
	      if(partjet_trueflav->at(matchrind.at(ij)) == jpdg.at(ij)) matchqual.at(ij) = -3;
	      else matchqual.at(ij) = -1;
	    }
	  }
	} 
      } // end of loop over other jets to remove ovelaps with same particle jets (if count == 1)
      if(abs(jpdg.at(ij)) == 15) continue;
      if(matchqual.at(ij) > 0 && partjet_trueflav->at(matchrind.at(ij)) == jpdg.at(ij)) matchqual.at(ij) = 3;
      // test of degrading HF reco HF matched to light part jet (too low pt meson)
      if(abs(jpdg.at(ij)) > 3 && abs(partjet_trueflav->at(matchrind.at(ij))) == 0) jpdg.at(ij) = 0;
      if(abs(partjet_id->at(matchrind.at(ij))) < 1) matchid.at(ij) = 2;
      else if(abs(partjet_id->at(matchrind.at(ij))) == 1 || abs(partjet_id->at(matchrind.at(ij))) == 2) matchid.at(ij) = 3;
      else {
	if(matchqual.at(ij) < 0) {
	  matchid.at(ij) = 2;	    
	  jpdg.at(ij) = 0;
	} else {
	  if(abs(partjet_trueflav->at(matchind.at(ij))) == 5 && partjet_id->at(matchind.at(ij)) < 3) matchid.at(ij) = 2; // others for b
	  else if(abs(partjet_trueflav->at(matchind.at(ij))) == 4 && partjet_id->at(matchind.at(ij)) > -3) matchid.at(ij) = 2;
	  else matchid.at(ij) = 1; // no problem for lights, same maps (as soon as not 0)
	}
	matchpdg.at(ij) = partjet_trueflav->at(matchind.at(ij));
      }
      // if(abs(jpdg.at(ij)) > 3 && matchid.at(ij) == 2 && partjet_count->at(matchind.at(ij)) > 1) matchid.at(ij) = 1;  
    } else { // not matched jets
      if(abs(jpdg.at(ij)) == 15) matchid.at(ij) = 0;
      else if(abs(jpdg.at(ij)) == 0) matchid.at(ij) = 2;
      else matchid.at(ij) = 2; // def=2  now eff = 0 // take others for not matched jets (for the moment)
    }
  }
}
